import { create } from 'zustand'

export interface SubScores {
  heat: number
  lightning: number
  flood: number
  wildfire: number
  wind: number
  wildlife: number
}

export interface SiteConditions {
  temp_f?: number
  heat_index_f?: number
  wind_mph?: number
  precip_in?: number
  humidity_pct?: number
  nws_alerts?: any[]
  usgs_gauge_ft?: number
  flood_stage_ft?: number
  heat_score?: number
  lightning_score?: number
  flood_score?: number
  wildfire_score?: number
  wind_score?: number
  wildlife_score?: number
  ml_risk_index?: number
  recorded_at?: string
}

export interface Site {
  id: number
  name: string
  utility?: string
  state?: string
  county?: string
  technology?: string
  capacity_mw?: number
  latitude: number
  longitude: number
  timezone?: string
  current_conditions?: SiteConditions | null
  risk_score?: number
  sub_scores?: SubScores
}

interface SiteStore {
  sites: Site[]
  loading: boolean
  error: string | null
  setSites: (sites: Site[]) => void
  updateSiteRisk: (plant_id: number, risk_score: number, sub_scores: SubScores) => void
  setLoading: (v: boolean) => void
  setError: (e: string | null) => void
}

export const useSiteStore = create<SiteStore>((set) => ({
  sites: [],
  loading: false,
  error: null,

  setSites: (sites) => set({ sites }),

  updateSiteRisk: (plant_id, risk_score, sub_scores) =>
    set((state) => ({
      sites: state.sites.map((s) =>
        s.id === plant_id
          ? {
              ...s,
              risk_score,
              sub_scores,
              current_conditions: s.current_conditions
                ? {
                    ...s.current_conditions,
                    ml_risk_index: risk_score,
                    heat_score: sub_scores.heat,
                    lightning_score: sub_scores.lightning,
                    flood_score: sub_scores.flood,
                    wildfire_score: sub_scores.wildfire,
                    wind_score: sub_scores.wind,
                    wildlife_score: sub_scores.wildlife,
                  }
                : s.current_conditions,
            }
          : s
      ),
    })),

  setLoading: (loading) => set({ loading }),
  setError: (error) => set({ error }),
}))
