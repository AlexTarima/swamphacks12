import { create } from 'zustand'

export interface AlertItem {
  id?: number
  plant_id: number
  alert_type?: string
  type?: string
  status?: string
  action?: string
  all_clear_at?: string | null
  strike_count?: number
  triggered_at?: string
}

interface AlertStore {
  activeAlerts: AlertItem[]
  addOrUpdateAlert: (alert: AlertItem) => void
  clearAlert: (plant_id: number, type: string) => void
  setAlerts: (alerts: AlertItem[]) => void
}

export const useAlertStore = create<AlertStore>((set) => ({
  activeAlerts: [],

  addOrUpdateAlert: (alert) =>
    set((state) => {
      const alertType = alert.alert_type || alert.type || 'unknown'
      const existing = state.activeAlerts.findIndex(
        (a) => a.plant_id === alert.plant_id && (a.alert_type === alertType || a.type === alertType)
      )
      if (existing >= 0) {
        const updated = [...state.activeAlerts]
        updated[existing] = { ...updated[existing], ...alert }
        return { activeAlerts: updated }
      }
      return { activeAlerts: [...state.activeAlerts, alert] }
    }),

  clearAlert: (plant_id, type) =>
    set((state) => ({
      activeAlerts: state.activeAlerts.filter(
        (a) => !(a.plant_id === plant_id && (a.alert_type === type || a.type === type))
      ),
    })),

  setAlerts: (alerts) => set({ activeAlerts: alerts }),
}))
