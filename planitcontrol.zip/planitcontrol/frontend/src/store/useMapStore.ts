import { create } from 'zustand'

interface MapStore {
  center: [number, number]
  zoom: number
  selectedSiteId: number | null
  setCenter: (center: [number, number]) => void
  setZoom: (zoom: number) => void
  setSelectedSite: (id: number | null) => void
}

export const useMapStore = create<MapStore>((set) => ({
  center: [33.0, -85.0],
  zoom: 6,
  selectedSiteId: null,
  setCenter: (center) => set({ center }),
  setZoom: (zoom) => set({ zoom }),
  setSelectedSite: (id) => set({ selectedSiteId: id }),
}))
