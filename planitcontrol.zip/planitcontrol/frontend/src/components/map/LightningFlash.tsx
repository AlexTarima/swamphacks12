import { CircleMarker } from 'react-leaflet'
import { useEffect, useState } from 'react'

interface Flash {
  id: string
  lat: number
  lon: number
  timestamp: number
}

interface Props {
  flashes: Flash[]
}

export default function LightningFlash({ flashes }: Props) {
  return (
    <>
      {flashes.map((flash) => (
        <CircleMarker
          key={flash.id}
          center={[flash.lat, flash.lon]}
          radius={6}
          pathOptions={{
            color: '#facc15',
            fillColor: '#facc15',
            fillOpacity: 0.8,
            weight: 2,
          }}
        />
      ))}
    </>
  )
}
