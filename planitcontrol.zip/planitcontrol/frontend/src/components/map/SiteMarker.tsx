import { Marker, Popup, Circle } from 'react-leaflet'
import L from 'leaflet'
import { Link } from 'react-router-dom'
import { Site } from '../../store/useSiteStore'

function getRiskColor(score: number): string {
  if (score >= 8) return '#ef4444'
  if (score >= 6) return '#f97316'
  if (score >= 3) return '#eab308'
  return '#22c55e'
}

function makeIcon(score: number, hasAlert: boolean): L.DivIcon {
  const color = getRiskColor(score)
  const size = score >= 6 ? 16 : 12
  const pulse = hasAlert ? `
    <span style="
      position: absolute; top: -4px; right: -4px;
      width: 10px; height: 10px;
      background: #ef4444; border-radius: 50%;
      animation: ping 1s cubic-bezier(0, 0, 0.2, 1) infinite;
    "></span>` : ''

  return L.divIcon({
    html: `
      <div style="position: relative; display: inline-block;">
        <div style="
          width: ${size}px; height: ${size}px;
          background: ${color};
          border: 2px solid white;
          border-radius: 50%;
          box-shadow: 0 0 8px ${color}88;
        "></div>
        ${pulse}
      </div>
    `,
    className: '',
    iconSize: [size + 8, size + 8],
    iconAnchor: [(size + 8) / 2, (size + 8) / 2],
  })
}

interface Props {
  site: Site
  hasAlert?: boolean
}

export default function SiteMarker({ site, hasAlert = false }: Props) {
  const score = site.current_conditions?.ml_risk_index ?? site.risk_score ?? 0
  const icon = makeIcon(score, hasAlert)
  const color = getRiskColor(score)
  const conditions = site.current_conditions

  return (
    <>
      {score >= 6 && (
        <Circle
          center={[site.latitude, site.longitude]}
          radius={5000}
          pathOptions={{ color, fillColor: color, fillOpacity: 0.08, weight: 1 }}
        />
      )}
      <Marker position={[site.latitude, site.longitude]} icon={icon}>
        <Popup className="site-popup" maxWidth={300}>
          <div className="bg-slate-800 text-slate-100 p-3 rounded-lg min-w-48">
            <div className="font-bold text-base mb-1">{site.name}</div>
            <div className="text-xs text-slate-400 mb-3">
              {site.technology} • {site.state} • {site.capacity_mw?.toFixed(0)} MW
            </div>

            {conditions && (
              <>
                <div className="grid grid-cols-2 gap-x-4 gap-y-1 text-sm mb-3">
                  <div><span className="text-slate-400">Risk:</span> <span style={{ color }} className="font-bold">{score.toFixed(1)}/10</span></div>
                  <div><span className="text-slate-400">Temp:</span> {conditions.temp_f?.toFixed(0)}°F</div>
                  <div><span className="text-slate-400">Wind:</span> {conditions.wind_mph?.toFixed(0)} mph</div>
                  <div><span className="text-slate-400">Humidity:</span> {conditions.humidity_pct?.toFixed(0)}%</div>
                </div>

                {conditions.nws_alerts && conditions.nws_alerts.length > 0 && (
                  <div className="mb-3">
                    {conditions.nws_alerts.slice(0, 2).map((a: any, i: number) => (
                      <div key={i} className="bg-red-900 text-red-200 text-xs px-2 py-1 rounded mb-1">
                        {a.event}
                      </div>
                    ))}
                  </div>
                )}
              </>
            )}

            <Link
              to={`/sites/${site.id}`}
              className="block text-center bg-blue-600 hover:bg-blue-500 text-white text-xs py-1.5 rounded transition-colors"
            >
              View Site Details →
            </Link>
          </div>
        </Popup>
      </Marker>
    </>
  )
}
