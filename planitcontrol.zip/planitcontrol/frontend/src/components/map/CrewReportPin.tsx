import { Marker, Popup } from 'react-leaflet'
import L from 'leaflet'

const HAZARD_EMOJI: Record<string, string> = {
  wildlife: '🐊',
  flooding: '🌊',
  lightning: '⚡',
  heat: '🌡️',
  structural: '🏗️',
  other: '⚠️',
}

function makeCrewIcon(hazardType: string): L.DivIcon {
  const emoji = HAZARD_EMOJI[hazardType] || '⚠️'
  return L.divIcon({
    html: `<div style="font-size:20px;line-height:1;filter:drop-shadow(0 1px 2px #000)">${emoji}</div>`,
    className: '',
    iconSize: [24, 24],
    iconAnchor: [12, 12],
  })
}

interface Report {
  report_id?: number
  id?: number
  plant_id: number
  lat?: number
  lon?: number
  latitude?: number
  longitude?: number
  type?: string
  hazard_type?: string
  reporter?: string
  reporter_name?: string
  notes?: string
  photo_path?: string
}

interface Props {
  report: Report
}

export default function CrewReportPin({ report }: Props) {
  const lat = report.lat ?? report.latitude
  const lon = report.lon ?? report.longitude
  const type = report.type ?? report.hazard_type ?? 'other'
  const reporter = report.reporter ?? report.reporter_name

  if (!lat || !lon) return null

  return (
    <Marker position={[lat, lon]} icon={makeCrewIcon(type)}>
      <Popup>
        <div className="bg-slate-800 text-slate-100 p-2 rounded text-sm min-w-40">
          <div className="font-bold mb-1">{HAZARD_EMOJI[type]} {type} hazard</div>
          {reporter && <div className="text-slate-400 text-xs">Reported by: {reporter}</div>}
          {report.notes && <div className="mt-1 text-xs">{report.notes}</div>}
          {report.photo_path && (
            <img
              src={`${import.meta.env.VITE_API_URL || ''}${report.photo_path}`}
              alt="hazard"
              className="mt-2 w-full rounded"
              style={{ maxHeight: 120, objectFit: 'cover' }}
            />
          )}
        </div>
      </Popup>
    </Marker>
  )
}
