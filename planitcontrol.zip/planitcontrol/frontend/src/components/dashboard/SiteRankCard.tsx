import { Link } from 'react-router-dom'
import RiskGauge from './RiskGauge'

interface Props {
  site: {
    id: number
    name: string
    state?: string
    technology?: string
    risk_score: number
    sub_scores?: Record<string, number>
    active_alerts?: any[]
    last_updated?: string
  }
  rank: number
}

function ScoreBar({ label, value }: { label: string; value: number }) {
  const color =
    value >= 8
      ? 'bg-red-500'
      : value >= 6
      ? 'bg-orange-500'
      : value >= 3
      ? 'bg-yellow-500'
      : 'bg-green-500'
  return (
    <div className="flex items-center gap-2 text-xs">
      <span className="text-slate-400 w-16">{label}</span>
      <div className="flex-1 bg-slate-700 rounded-full h-1.5">
        <div className={`h-1.5 rounded-full ${color}`} style={{ width: `${(value / 10) * 100}%` }} />
      </div>
      <span className="text-slate-300 w-6 text-right">{value.toFixed(0)}</span>
    </div>
  )
}

export default function SiteRankCard({ site, rank }: Props) {
  const hasLightning = site.active_alerts?.some((a) => a.type === 'lightning')
  const scores = site.sub_scores || {}

  return (
    <Link
      to={`/sites/${site.id}`}
      className="block bg-slate-800 hover:bg-slate-750 border border-slate-700 hover:border-slate-500 rounded-xl p-4 transition-all"
    >
      <div className="flex items-start gap-4">
        <div className="text-2xl font-bold text-slate-500 w-8 text-right">#{rank}</div>

        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 mb-1">
            <h3 className="font-semibold text-slate-100 truncate">{site.name}</h3>
            {hasLightning && <span className="text-yellow-400 animate-pulse">&#9889;</span>}
          </div>
          <div className="text-xs text-slate-400 mb-3">
            {site.technology} &bull; {site.state}
          </div>

          <div className="space-y-1">
            <ScoreBar label="Lightning" value={scores.lightning || 0} />
            <ScoreBar label="Heat" value={scores.heat || 0} />
            <ScoreBar label="Flood" value={scores.flood || 0} />
            <ScoreBar label="Wind" value={scores.wind || 0} />
          </div>
        </div>

        <RiskGauge score={site.risk_score || 0} size={90} />
      </div>

      {site.active_alerts && site.active_alerts.length > 0 && (
        <div className="mt-3 flex gap-2 flex-wrap">
          {site.active_alerts.map((a, i) => (
            <span key={i} className="bg-red-900 text-red-300 text-xs px-2 py-0.5 rounded-full">
              {a.type} alert
            </span>
          ))}
        </div>
      )}
    </Link>
  )
}
