import { RadialBarChart, RadialBar, PolarAngleAxis } from 'recharts'

interface RiskGaugeProps {
  score: number
  size?: number
}

function getRiskColor(score: number): string {
  if (score >= 8) return '#ef4444'
  if (score >= 6) return '#f97316'
  if (score >= 3) return '#eab308'
  return '#22c55e'
}

function getRiskLabel(score: number): string {
  if (score >= 8) return 'CRITICAL'
  if (score >= 6) return 'HIGH'
  if (score >= 3) return 'MODERATE'
  return 'LOW'
}

export default function RiskGauge({ score, size = 120 }: RiskGaugeProps) {
  const color = getRiskColor(score)
  const data = [{ value: score, fill: color }]

  return (
    <div className="flex flex-col items-center">
      <RadialBarChart
        width={size}
        height={size}
        cx={size / 2}
        cy={size / 2}
        innerRadius={size * 0.35}
        outerRadius={size * 0.48}
        data={data}
        startAngle={225}
        endAngle={-45}
      >
        <PolarAngleAxis type="number" domain={[0, 10]} angleAxisId={0} tick={false} />
        <RadialBar
          dataKey="value"
          cornerRadius={4}
          background={{ fill: '#1e293b' }}
          angleAxisId={0}
        />
      </RadialBarChart>
      <div className="text-center -mt-2">
        <div className="text-2xl font-bold" style={{ color }}>{score.toFixed(1)}</div>
        <div className="text-xs font-semibold" style={{ color }}>{getRiskLabel(score)}</div>
      </div>
    </div>
  )
}
