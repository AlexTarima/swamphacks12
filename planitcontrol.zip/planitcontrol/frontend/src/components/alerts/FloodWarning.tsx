interface FloodWarningProps {
  gaugeFt?: number
  floodStageFt?: number
  score: number
}

export default function FloodWarning({ gaugeFt, floodStageFt, score }: FloodWarningProps) {
  if (score < 3) return null

  const ratio = gaugeFt && floodStageFt ? gaugeFt / floodStageFt : null
  const pct = ratio ? Math.round(ratio * 100) : null

  return (
    <div className="bg-blue-900 border border-blue-500 rounded-lg p-3 flex items-center gap-3">
      <span className="text-2xl">&#127754;</span>
      <div>
        <div className="font-bold text-blue-200">Flood Warning</div>
        {pct !== null && (
          <div className="text-sm text-blue-300">
            Gauge at {pct}% of flood stage ({gaugeFt?.toFixed(1)} ft / {floodStageFt?.toFixed(1)} ft)
          </div>
        )}
      </div>
      <span className="ml-auto text-blue-400 font-bold">{score.toFixed(1)}/10</span>
    </div>
  )
}
