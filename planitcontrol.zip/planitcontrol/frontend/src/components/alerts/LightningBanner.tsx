import { AlertItem } from '../../store/useAlertStore'
import { useLightningTimer } from '../../hooks/useLightningTimer'
import TimerBadge from '../shared/TimerBadge'
import { useSiteStore } from '../../store/useSiteStore'

interface Props {
  alerts: AlertItem[]
}

function SingleAlert({ alert }: { alert: AlertItem }) {
  const remaining = useLightningTimer(alert.all_clear_at)
  const sites = useSiteStore((s) => s.sites)
  const site = sites.find((s) => s.id === alert.plant_id)

  return (
    <div className="flex items-center gap-4 flex-wrap">
      <span className="text-2xl">&#9889;</span>
      <div>
        <span className="font-bold">STOP WORK — Lightning Alert</span>
        {site && <span className="ml-2 text-yellow-200">@ {site.name}</span>}
        <span className="ml-2 text-sm opacity-80">
          ({alert.strike_count || 0} strike{(alert.strike_count || 0) !== 1 ? 's' : ''} detected)
        </span>
      </div>
      <div className="ml-auto flex items-center gap-2">
        <span className="text-sm opacity-80">All-clear in:</span>
        {remaining > 0 ? (
          <TimerBadge seconds={remaining} className="text-white text-xl" />
        ) : (
          <span className="font-mono font-bold text-xl">Clearing...</span>
        )}
      </div>
    </div>
  )
}

export default function LightningBanner({ alerts }: Props) {
  return (
    <div className="lightning-banner bg-red-600 text-white px-6 py-3 z-50">
      {alerts.map((alert, i) => (
        <SingleAlert key={`${alert.plant_id}-${i}`} alert={alert} />
      ))}
    </div>
  )
}
