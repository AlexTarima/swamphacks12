interface TimerBadgeProps {
  seconds: number
  className?: string
}

export default function TimerBadge({ seconds, className = '' }: TimerBadgeProps) {
  const mins = Math.floor(seconds / 60)
  const secs = seconds % 60
  const display = `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`

  return (
    <span className={`font-mono font-bold tabular-nums ${className}`}>
      {display}
    </span>
  )
}
