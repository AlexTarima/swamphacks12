import { BrowserRouter, Routes, Route, Link, useLocation } from 'react-router-dom'
import MapView from './pages/MapView'
import Dashboard from './pages/Dashboard'
import SiteDetail from './pages/SiteDetail'
import CrewReporter from './pages/CrewReporter'
import BriefingView from './pages/BriefingView'
import { useSocket } from './hooks/useSocket'
import { useAlertStore } from './store/useAlertStore'
import LightningBanner from './components/alerts/LightningBanner'

function Nav() {
  const location = useLocation()
  const links = [
    { to: '/', label: 'Map' },
    { to: '/dashboard', label: 'Dashboard' },
    { to: '/crew', label: 'Report Hazard' },
  ]
  return (
    <nav className="bg-slate-900 border-b border-slate-700 px-4 py-2 flex items-center gap-6 z-50">
      <span className="text-blue-400 font-bold text-lg tracking-wide">PlanIT Control</span>
      {links.map(l => (
        <Link
          key={l.to}
          to={l.to}
          className={`text-sm font-medium transition-colors ${
            location.pathname === l.to
              ? 'text-blue-400'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          {l.label}
        </Link>
      ))}
      <span className="ml-auto text-xs text-slate-500">SwampHacks 2024</span>
    </nav>
  )
}

function AppContent() {
  useSocket()
  const activeAlerts = useAlertStore(s => s.activeAlerts)
  const lightningAlerts = activeAlerts.filter(a => a.alert_type === 'lightning' || a.type === 'lightning')

  return (
    <div className="flex flex-col h-screen">
      <Nav />
      {lightningAlerts.length > 0 && (
        <LightningBanner alerts={lightningAlerts} />
      )}
      <div className="flex-1 overflow-hidden">
        <Routes>
          <Route path="/" element={<MapView />} />
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="/sites/:id" element={<SiteDetail />} />
          <Route path="/crew" element={<CrewReporter />} />
          <Route path="/briefing/:id" element={<BriefingView />} />
        </Routes>
      </div>
    </div>
  )
}

export default function App() {
  return (
    <BrowserRouter>
      <AppContent />
    </BrowserRouter>
  )
}
