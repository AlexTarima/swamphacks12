import { useEffect, useState } from 'react'
import { MapContainer, TileLayer, ZoomControl } from 'react-leaflet'
import axios from 'axios'
import SiteMarker from '../components/map/SiteMarker'
import CrewReportPin from '../components/map/CrewReportPin'
import LightningFlash from '../components/map/LightningFlash'
import { useSiteStore } from '../store/useSiteStore'
import { useAlertStore } from '../store/useAlertStore'

const API = import.meta.env.VITE_API_URL || ''

export default function MapView() {
  const { sites, setSites, setLoading, setError } = useSiteStore()
  const activeAlerts = useAlertStore((s) => s.activeAlerts)
  const setAlerts = useAlertStore((s) => s.setAlerts)
  const [crewReports, setCrewReports] = useState<any[]>([])
  const [flashes, setFlashes] = useState<any[]>([])

  useEffect(() => {
    setLoading(true)
    Promise.all([
      axios.get(`${API}/api/sites`),
      axios.get(`${API}/api/alerts`),
      axios.get(`${API}/api/crew/reports`),
    ])
      .then(([sitesRes, alertsRes, crewRes]) => {
        setSites(sitesRes.data)
        setAlerts(alertsRes.data)
        setCrewReports(crewRes.data)
        setLoading(false)
      })
      .catch((err) => {
        setError('Failed to load data')
        setLoading(false)
        console.error(err)
      })
  }, [])

  const alertedPlantIds = new Set(
    activeAlerts
      .filter((a) => a.status === 'active')
      .map((a) => a.plant_id)
  )

  return (
    <div className="h-full w-full relative">
      <MapContainer
        center={[33.0, -85.0]}
        zoom={6}
        style={{ height: '100%', width: '100%' }}
        zoomControl={false}
      >
        <ZoomControl position="bottomright" />

        {/* Dark map tiles */}
        <TileLayer
          url="https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png"
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> &copy; <a href="https://carto.com/attributions">CARTO</a>'
          maxZoom={19}
        />

        {/* Plant markers */}
        {sites.map((site) => (
          <SiteMarker
            key={site.id}
            site={site}
            hasAlert={alertedPlantIds.has(site.id)}
          />
        ))}

        {/* Crew report pins */}
        {crewReports.map((report) => (
          <CrewReportPin key={report.id} report={report} />
        ))}

        {/* Lightning flashes */}
        <LightningFlash flashes={flashes} />
      </MapContainer>

      {/* Map legend */}
      <div className="absolute bottom-8 left-4 z-[1000] bg-slate-900 bg-opacity-90 rounded-lg p-3 text-xs">
        <div className="font-bold text-slate-300 mb-2">Risk Level</div>
        {[
          { color: '#22c55e', label: 'Low (0-3)' },
          { color: '#eab308', label: 'Moderate (3-6)' },
          { color: '#f97316', label: 'High (6-8)' },
          { color: '#ef4444', label: 'Critical (8-10)' },
        ].map(({ color, label }) => (
          <div key={label} className="flex items-center gap-2 mb-1">
            <div className="w-3 h-3 rounded-full border border-white" style={{ backgroundColor: color }} />
            <span className="text-slate-300">{label}</span>
          </div>
        ))}
      </div>

      {/* Site count badge */}
      <div className="absolute top-4 right-4 z-[1000] bg-slate-900 bg-opacity-90 rounded-lg px-3 py-2 text-sm">
        <span className="text-blue-400 font-bold">{sites.length}</span>
        <span className="text-slate-400 ml-1">sites monitored</span>
      </div>
    </div>
  )
}
