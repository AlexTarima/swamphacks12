import { useEffect, useState } from 'react'
import axios from 'axios'
import SiteRankCard from '../components/dashboard/SiteRankCard'
import { useSiteStore } from '../store/useSiteStore'

const API = import.meta.env.VITE_API_URL || ''

export default function Dashboard() {
  const [rankedSites, setRankedSites] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [filter, setFilter] = useState<'all' | 'critical' | 'alerts'>('all')
  const updateSiteRisk = useSiteStore((s) => s.updateSiteRisk)

  const fetchRanked = async () => {
    try {
      const res = await axios.get(`${API}/api/dashboard/ranked`)
      setRankedSites(res.data)
      res.data.forEach((s: any) => {
        if (s.sub_scores) {
          updateSiteRisk(s.id, s.risk_score, s.sub_scores)
        }
      })
    } catch (err) {
      console.error('Failed to load ranked sites', err)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchRanked()
    const interval = setInterval(fetchRanked, 30000)
    return () => clearInterval(interval)
  }, [])

  const filtered = rankedSites.filter((s) => {
    if (filter === 'critical') return s.risk_score >= 8
    if (filter === 'alerts') return s.active_alerts?.length > 0
    return true
  })

  if (loading) {
    return (
      <div className="flex items-center justify-center h-full text-slate-400">
        <div className="text-center">
          <div className="text-4xl mb-4">&#9889;</div>
          <div>Loading hazard data...</div>
        </div>
      </div>
    )
  }

  const criticalCount = rankedSites.filter((s) => s.risk_score >= 8).length
  const alertCount = rankedSites.filter((s) => s.active_alerts?.length > 0).length

  return (
    <div className="h-full overflow-y-auto bg-slate-900 p-6">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="mb-6">
          <h1 className="text-2xl font-bold text-slate-100">Risk Dashboard</h1>
          <p className="text-slate-400 text-sm mt-1">
            Sites ranked by ML risk index — updates every 30s
          </p>
        </div>

        {/* Stats row */}
        <div className="grid grid-cols-3 gap-4 mb-6">
          <div className="bg-slate-800 rounded-xl p-4 text-center">
            <div className="text-3xl font-bold text-slate-100">{rankedSites.length}</div>
            <div className="text-xs text-slate-400 mt-1">Sites Monitored</div>
          </div>
          <div className="bg-red-950 border border-red-800 rounded-xl p-4 text-center">
            <div className="text-3xl font-bold text-red-400">{criticalCount}</div>
            <div className="text-xs text-red-300 mt-1">Critical Risk</div>
          </div>
          <div className="bg-yellow-950 border border-yellow-800 rounded-xl p-4 text-center">
            <div className="text-3xl font-bold text-yellow-400">{alertCount}</div>
            <div className="text-xs text-yellow-300 mt-1">Active Alerts</div>
          </div>
        </div>

        {/* Filter tabs */}
        <div className="flex gap-2 mb-4">
          {(['all', 'critical', 'alerts'] as const).map((f) => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={`px-4 py-1.5 rounded-full text-sm font-medium transition-colors ${
                filter === f
                  ? 'bg-blue-600 text-white'
                  : 'bg-slate-800 text-slate-400 hover:text-slate-200'
              }`}
            >
              {f === 'all' ? 'All Sites' : f === 'critical' ? 'Critical Only' : 'With Alerts'}
            </button>
          ))}
          <span className="ml-auto text-xs text-slate-500 self-center">
            {filtered.length} shown
          </span>
        </div>

        {/* Site cards */}
        <div className="space-y-3">
          {filtered.map((site, i) => (
            <SiteRankCard key={site.id} site={site} rank={i + 1} />
          ))}
          {filtered.length === 0 && (
            <div className="text-center text-slate-400 py-12">
              No sites match the current filter
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
