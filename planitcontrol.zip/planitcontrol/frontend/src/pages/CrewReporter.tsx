import { useState, useRef } from 'react'
import axios from 'axios'

const API = import.meta.env.VITE_API_URL || ''

const HAZARD_TYPES = [
  { value: 'wildlife', label: 'Wildlife', desc: 'Alligators, snakes, or other dangerous animals' },
  { value: 'flooding', label: 'Flooding', desc: 'Standing water, flooded access road' },
  { value: 'lightning', label: 'Lightning', desc: 'Observed lightning activity' },
  { value: 'heat', label: 'Heat', desc: 'Extreme heat conditions' },
  { value: 'structural', label: 'Structural', desc: 'Damaged infrastructure or equipment' },
  { value: 'other', label: 'Other', desc: 'Other hazard not listed' },
]

type Step = 'location' | 'type' | 'photo' | 'submit' | 'done'

export default function CrewReporter() {
  const [step, setStep] = useState<Step>('location')
  const [plantId, setPlantId] = useState<number>(1)
  const [reporterName, setReporterName] = useState('')
  const [hazardType, setHazardType] = useState('')
  const [notes, setNotes] = useState('')
  const [lat, setLat] = useState<number | null>(null)
  const [lon, setLon] = useState<number | null>(null)
  const [photo, setPhoto] = useState<File | null>(null)
  const [photoPreview, setPhotoPreview] = useState<string | null>(null)
  const [submitting, setSubmitting] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [gpsStatus, setGpsStatus] = useState<'idle' | 'loading' | 'ok' | 'error'>('idle')
  const fileRef = useRef<HTMLInputElement>(null)

  const getGPS = () => {
    setGpsStatus('loading')
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setLat(pos.coords.latitude)
        setLon(pos.coords.longitude)
        setGpsStatus('ok')
      },
      () => {
        setGpsStatus('error')
        // Use plant approximate location as fallback
        setLat(25.5)
        setLon(-80.5)
      },
      { timeout: 10000, enableHighAccuracy: true }
    )
  }

  const handlePhotoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      setPhoto(file)
      const reader = new FileReader()
      reader.onload = () => setPhotoPreview(reader.result as string)
      reader.readAsDataURL(file)
    }
  }

  const handleSubmit = async () => {
    if (!hazardType || !reporterName) {
      setError('Name and hazard type are required')
      return
    }
    setSubmitting(true)
    setError(null)

    const formData = new FormData()
    formData.append('plant_id', String(plantId))
    formData.append('reporter_name', reporterName)
    formData.append('hazard_type', hazardType)
    formData.append('notes', notes)
    if (lat !== null) formData.append('latitude', String(lat))
    if (lon !== null) formData.append('longitude', String(lon))
    if (photo) formData.append('photo', photo)

    try {
      await axios.post(`${API}/api/crew/reports`, formData, {
        headers: { 'Content-Type': 'multipart/form-data' },
      })
      setStep('done')
    } catch (err) {
      setError('Submission failed. Please try again.')
    } finally {
      setSubmitting(false)
    }
  }

  if (step === 'done') {
    return (
      <div className="flex flex-col items-center justify-center h-full gap-6 p-8">
        <div className="text-6xl">&#9989;</div>
        <h2 className="text-2xl font-bold text-green-400">Report Submitted!</h2>
        <p className="text-slate-400 text-center">
          Your hazard report has been sent to supervisors and a pin has been placed on the map.
        </p>
        <button
          onClick={() => {
            setStep('location')
            setHazardType('')
            setNotes('')
            setPhoto(null)
            setPhotoPreview(null)
          }}
          className="bg-blue-600 hover:bg-blue-500 text-white px-6 py-3 rounded-xl font-medium"
        >
          Submit Another Report
        </button>
      </div>
    )
  }

  return (
    <div className="h-full overflow-y-auto bg-slate-900 p-4 max-w-lg mx-auto">
      <div className="mb-6">
        <h1 className="text-xl font-bold text-slate-100">Report Field Hazard</h1>
        <p className="text-slate-400 text-sm mt-1">Submit a hazard report from the field</p>
      </div>

      {/* Reporter name */}
      <div className="mb-4">
        <label className="block text-sm font-medium text-slate-300 mb-2">Your Name *</label>
        <input
          type="text"
          value={reporterName}
          onChange={(e) => setReporterName(e.target.value)}
          placeholder="John Smith"
          className="w-full bg-slate-800 border border-slate-600 rounded-lg px-4 py-3 text-slate-100 placeholder-slate-500 focus:outline-none focus:border-blue-500"
        />
      </div>

      {/* Hazard type */}
      <div className="mb-4">
        <label className="block text-sm font-medium text-slate-300 mb-2">Hazard Type *</label>
        <div className="grid grid-cols-2 gap-2">
          {HAZARD_TYPES.map((h) => (
            <button
              key={h.value}
              onClick={() => setHazardType(h.value)}
              className={`p-3 rounded-xl border text-left transition-all ${
                hazardType === h.value
                  ? 'border-blue-500 bg-blue-950 text-blue-100'
                  : 'border-slate-600 bg-slate-800 text-slate-300 hover:border-slate-400'
              }`}
            >
              <div className="font-medium text-sm">{h.label}</div>
              <div className="text-xs opacity-70 mt-0.5">{h.desc}</div>
            </button>
          ))}
        </div>
      </div>

      {/* Notes */}
      <div className="mb-4">
        <label className="block text-sm font-medium text-slate-300 mb-2">Notes</label>
        <textarea
          value={notes}
          onChange={(e) => setNotes(e.target.value)}
          placeholder="Describe the hazard in detail..."
          rows={3}
          className="w-full bg-slate-800 border border-slate-600 rounded-lg px-4 py-3 text-slate-100 placeholder-slate-500 focus:outline-none focus:border-blue-500 resize-none"
        />
      </div>

      {/* GPS */}
      <div className="mb-4">
        <label className="block text-sm font-medium text-slate-300 mb-2">Location</label>
        <button
          onClick={getGPS}
          className="w-full bg-slate-800 border border-slate-600 hover:border-slate-400 rounded-lg px-4 py-3 text-left transition-colors"
        >
          {gpsStatus === 'idle' && <span className="text-slate-400">Tap to get GPS location</span>}
          {gpsStatus === 'loading' && <span className="text-yellow-400">Getting location...</span>}
          {gpsStatus === 'ok' && <span className="text-green-400">Location: {lat?.toFixed(4)}, {lon?.toFixed(4)}</span>}
          {gpsStatus === 'error' && <span className="text-orange-400">GPS unavailable — using approximate location</span>}
        </button>
      </div>

      {/* Photo */}
      <div className="mb-6">
        <label className="block text-sm font-medium text-slate-300 mb-2">Photo (optional)</label>
        <input
          ref={fileRef}
          type="file"
          accept="image/*"
          capture="environment"
          onChange={handlePhotoChange}
          className="hidden"
        />
        {photoPreview ? (
          <div className="relative">
            <img src={photoPreview} alt="preview" className="w-full h-40 object-cover rounded-lg" />
            <button
              onClick={() => { setPhoto(null); setPhotoPreview(null) }}
              className="absolute top-2 right-2 bg-red-600 text-white rounded-full w-7 h-7 flex items-center justify-center text-sm"
            >
              &times;
            </button>
          </div>
        ) : (
          <button
            onClick={() => fileRef.current?.click()}
            className="w-full bg-slate-800 border border-dashed border-slate-500 hover:border-slate-300 rounded-lg px-4 py-6 text-slate-400 hover:text-slate-200 transition-colors text-center"
          >
            Take Photo / Choose File
          </button>
        )}
      </div>

      {error && (
        <div className="bg-red-950 border border-red-700 text-red-300 rounded-lg px-4 py-3 mb-4 text-sm">
          {error}
        </div>
      )}

      <button
        onClick={handleSubmit}
        disabled={submitting || !reporterName || !hazardType}
        className="w-full bg-blue-600 hover:bg-blue-500 disabled:bg-slate-700 disabled:text-slate-500 text-white font-bold py-4 rounded-xl text-lg transition-colors"
      >
        {submitting ? 'Submitting...' : 'Submit Report'}
      </button>
    </div>
  )
}
