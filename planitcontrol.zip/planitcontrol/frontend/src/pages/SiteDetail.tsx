import { useEffect, useState } from 'react'
import { useParams, Link } from 'react-router-dom'
import axios from 'axios'
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts'
import RiskGauge from '../components/dashboard/RiskGauge'
import FloodWarning from '../components/alerts/FloodWarning'
import { useAlertStore } from '../store/useAlertStore'
import { useLightningTimer } from '../hooks/useLightningTimer'
import TimerBadge from '../components/shared/TimerBadge'

const API = import.meta.env.VITE_API_URL || ''

function LightningCountdown({ alert }: { alert: any }) {
  const remaining = useLightningTimer(alert.all_clear_at)
  return (
    <div className="bg-red-950 border border-red-600 rounded-xl p-4 flex items-center gap-4">
      <span className="text-3xl">&#9889;</span>
      <div className="flex-1">
        <div className="font-bold text-red-300">STOP WORK — Lightning Alert Active</div>
        <div className="text-sm text-red-400">{alert.strike_count} strike(s) within 10 miles</div>
      </div>
      <div className="text-center">
        <div className="text-xs text-red-400 mb-1">All-clear in</div>
        <TimerBadge seconds={remaining} className="text-white text-2xl" />
      </div>
    </div>
  )
}

export default function SiteDetail() {
  const { id } = useParams<{ id: string }>()
  const [site, setSite] = useState<any>(null)
  const [alerts, setAlerts] = useState<any[]>([])
  const [briefing, setBriefing] = useState<any>(null)
  const [loading, setLoading] = useState(true)
  const activeAlerts = useAlertStore((s) => s.activeAlerts)

  useEffect(() => {
    if (!id) return
    Promise.all([
      axios.get(`${API}/api/sites/${id}`),
      axios.get(`${API}/api/alerts/${id}`),
      axios.get(`${API}/api/briefings/${id}/latest`).catch(() => null),
    ]).then(([siteRes, alertsRes, briefingRes]) => {
      setSite(siteRes.data)
      setAlerts(alertsRes.data)
      if (briefingRes) setBriefing(briefingRes.data)
      setLoading(false)
    }).catch(() => setLoading(false))
  }, [id])

  const liveAlerts = activeAlerts.filter((a) => a.plant_id === Number(id))
  const lightningAlert = liveAlerts.find((a) => a.alert_type === 'lightning' || a.type === 'lightning')

  if (loading) return <div className="flex items-center justify-center h-full text-slate-400">Loading...</div>
  if (!site) return <div className="flex items-center justify-center h-full text-red-400">Site not found</div>

  const latest = site.recent_snapshots?.[0]
  const riskScore = latest?.ml_risk_index ?? 0

  const chartData = [...(site.recent_snapshots || [])].reverse().map((s: any) => ({
    time: s.recorded_at ? new Date(s.recorded_at).toLocaleTimeString() : '',
    risk: s.ml_risk_index || 0,
    heat: s.heat_score || 0,
    lightning: s.lightning_score || 0,
    flood: s.flood_score || 0,
    wind: s.wind_score || 0,
  }))

  return (
    <div className="h-full overflow-y-auto bg-slate-900 p-6">
      <div className="max-w-4xl mx-auto">
        {/* Breadcrumb */}
        <div className="mb-4">
          <Link to="/dashboard" className="text-blue-400 hover:text-blue-300 text-sm">
            &larr; Dashboard
          </Link>
        </div>

        {/* Header */}
        <div className="flex items-start gap-6 mb-6">
          <div className="flex-1">
            <h1 className="text-2xl font-bold text-slate-100">{site.name}</h1>
            <div className="text-slate-400 text-sm mt-1">
              {site.technology} &bull; {site.county}, {site.state} &bull; {site.capacity_mw?.toFixed(0)} MW &bull; {site.utility}
            </div>
          </div>
          <RiskGauge score={riskScore} size={120} />
        </div>

        {/* Lightning alert */}
        {lightningAlert && <div className="mb-4"><LightningCountdown alert={lightningAlert} /></div>}

        {/* Flood warning */}
        {latest && (
          <div className="mb-4">
            <FloodWarning
              gaugeFt={latest.usgs_gauge_ft}
              floodStageFt={latest.flood_stage_ft}
              score={latest.flood_score || 0}
            />
          </div>
        )}

        {/* Current conditions */}
        {latest && (
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
            {[
              { label: 'Temperature', value: `${latest.temp_f?.toFixed(0)}°F` },
              { label: 'Heat Index', value: `${latest.heat_index_f?.toFixed(0)}°F` },
              { label: 'Wind Speed', value: `${latest.wind_mph?.toFixed(0)} mph` },
              { label: 'Humidity', value: `${latest.humidity_pct?.toFixed(0)}%` },
            ].map(({ label, value }) => (
              <div key={label} className="bg-slate-800 rounded-xl p-4 text-center">
                <div className="text-xl font-bold text-slate-100">{value || '—'}</div>
                <div className="text-xs text-slate-400 mt-1">{label}</div>
              </div>
            ))}
          </div>
        )}

        {/* Sub-scores */}
        {latest && (
          <div className="bg-slate-800 rounded-xl p-4 mb-6">
            <h3 className="font-semibold text-slate-200 mb-3">Hazard Sub-Scores</h3>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
              {[
                { label: 'Lightning', value: latest.lightning_score || 0 },
                { label: 'Heat', value: latest.heat_score || 0 },
                { label: 'Flood', value: latest.flood_score || 0 },
                { label: 'Wind', value: latest.wind_score || 0 },
                { label: 'Wildfire', value: latest.wildfire_score || 0 },
                { label: 'Wildlife', value: latest.wildlife_score || 0 },
              ].map(({ label, value }) => {
                const color = value >= 8 ? 'text-red-400' : value >= 6 ? 'text-orange-400' : value >= 3 ? 'text-yellow-400' : 'text-green-400'
                const bg = value >= 8 ? 'bg-red-950' : value >= 6 ? 'bg-orange-950' : value >= 3 ? 'bg-yellow-950' : 'bg-green-950'
                return (
                  <div key={label} className={`${bg} rounded-lg p-3 flex items-center justify-between`}>
                    <span className="text-sm text-slate-300">{label}</span>
                    <span className={`font-bold ${color}`}>{value.toFixed(1)}</span>
                  </div>
                )
              })}
            </div>
          </div>
        )}

        {/* NWS Alerts */}
        {latest?.nws_alerts && latest.nws_alerts.length > 0 && (
          <div className="bg-red-950 border border-red-700 rounded-xl p-4 mb-6">
            <h3 className="font-semibold text-red-300 mb-2">Active NWS Alerts</h3>
            {latest.nws_alerts.map((alert: any, i: number) => (
              <div key={i} className="text-sm text-red-200 mb-1">
                <span className="font-medium">{alert.event}</span>
                {alert.headline && <span className="text-red-300 ml-2">— {alert.headline}</span>}
              </div>
            ))}
          </div>
        )}

        {/* Risk history chart */}
        {chartData.length > 1 && (
          <div className="bg-slate-800 rounded-xl p-4 mb-6">
            <h3 className="font-semibold text-slate-200 mb-4">Risk Score History</h3>
            <ResponsiveContainer width="100%" height={200}>
              <LineChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                <XAxis dataKey="time" tick={{ fill: '#94a3b8', fontSize: 11 }} />
                <YAxis domain={[0, 10]} tick={{ fill: '#94a3b8', fontSize: 11 }} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155' }}
                  labelStyle={{ color: '#94a3b8' }}
                />
                <Legend />
                <Line type="monotone" dataKey="risk" stroke="#3b82f6" strokeWidth={2} dot={false} name="Overall" />
                <Line type="monotone" dataKey="lightning" stroke="#facc15" strokeWidth={1.5} dot={false} name="Lightning" />
                <Line type="monotone" dataKey="heat" stroke="#ef4444" strokeWidth={1.5} dot={false} name="Heat" />
                <Line type="monotone" dataKey="flood" stroke="#60a5fa" strokeWidth={1.5} dot={false} name="Flood" />
              </LineChart>
            </ResponsiveContainer>
          </div>
        )}

        {/* Daily briefing */}
        {briefing && (
          <div className="bg-slate-800 rounded-xl p-4 mb-6">
            <div className="flex items-center justify-between mb-3">
              <h3 className="font-semibold text-slate-200">Daily Safety Briefing</h3>
              <span className="text-xs text-slate-400">{briefing.briefing_date}</span>
            </div>
            <p className="text-slate-300 text-sm mb-3">{briefing.summary}</p>

            {briefing.hazards?.length > 0 && (
              <div className="flex gap-2 flex-wrap mb-3">
                {briefing.hazards.map((h: string) => (
                  <span key={h} className="bg-orange-900 text-orange-300 text-xs px-2 py-0.5 rounded-full">
                    {h}
                  </span>
                ))}
              </div>
            )}

            <div className="space-y-1">
              {briefing.safety_actions?.slice(0, 6).map((action: string, i: number) => (
                <div key={i} className="flex items-start gap-2 text-sm">
                  <span className="text-green-400 mt-0.5">&#10003;</span>
                  <span className="text-slate-300">{action}</span>
                </div>
              ))}
            </div>

            <Link
              to={`/briefing/${site.id}`}
              className="mt-3 block text-center text-blue-400 hover:text-blue-300 text-sm"
            >
              View full briefing &rarr;
            </Link>
          </div>
        )}
      </div>
    </div>
  )
}
