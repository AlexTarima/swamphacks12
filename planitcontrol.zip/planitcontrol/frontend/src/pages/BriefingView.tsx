import { useEffect, useState } from 'react'
import { useParams, Link } from 'react-router-dom'
import axios from 'axios'

const API = import.meta.env.VITE_API_URL || ''

function RiskBadge({ score }: { score?: number }) {
  if (!score) return null
  const color = score >= 7 ? 'bg-red-900 text-red-300' : score >= 4 ? 'bg-yellow-900 text-yellow-300' : 'bg-green-900 text-green-300'
  const label = score >= 7 ? 'HIGH RISK' : score >= 4 ? 'MODERATE' : 'LOW RISK'
  return (
    <span className={`${color} text-xs font-bold px-2 py-0.5 rounded-full`}>
      {label}
    </span>
  )
}

export default function BriefingView() {
  const { id } = useParams<{ id: string }>()
  const [briefing, setBriefing] = useState<any>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    if (!id) return
    axios.get(`${API}/api/briefings/${id}/latest`)
      .then((res) => { setBriefing(res.data); setLoading(false) })
      .catch(() => setLoading(false))
  }, [id])

  if (loading) return <div className="flex items-center justify-center h-full text-slate-400">Loading briefing...</div>
  if (!briefing) return (
    <div className="flex flex-col items-center justify-center h-full gap-4 text-slate-400">
      <div className="text-4xl">&#128203;</div>
      <p>No briefing available for this site yet.</p>
      <p className="text-sm">Briefings are generated daily at 6 PM local time.</p>
      <Link to="/dashboard" className="text-blue-400 hover:text-blue-300 text-sm">&larr; Back to Dashboard</Link>
    </div>
  )

  return (
    <div className="h-full overflow-y-auto bg-slate-900 p-6">
      <div className="max-w-2xl mx-auto">
        <Link to={`/sites/${id}`} className="text-blue-400 hover:text-blue-300 text-sm">
          &larr; Back to Site
        </Link>

        <div className="mt-4 mb-6">
          <div className="flex items-center justify-between">
            <h1 className="text-2xl font-bold text-slate-100">Daily Safety Briefing</h1>
            <span className="text-sm text-slate-400">{briefing.briefing_date}</span>
          </div>
          <p className="text-slate-300 mt-3 leading-relaxed">{briefing.summary}</p>
        </div>

        {/* Hazards */}
        {briefing.hazards?.length > 0 && (
          <div className="bg-orange-950 border border-orange-700 rounded-xl p-4 mb-6">
            <h2 className="font-semibold text-orange-300 mb-3">Expected Hazards Tomorrow</h2>
            <div className="flex gap-2 flex-wrap">
              {briefing.hazards.map((h: string) => (
                <span key={h} className="bg-orange-900 text-orange-200 px-3 py-1 rounded-full text-sm font-medium capitalize">
                  {h}
                </span>
              ))}
            </div>
          </div>
        )}

        {/* Safety actions */}
        {briefing.safety_actions?.length > 0 && (
          <div className="bg-slate-800 rounded-xl p-4 mb-6">
            <h2 className="font-semibold text-slate-200 mb-3">Safety Actions Required</h2>
            <div className="space-y-2">
              {briefing.safety_actions.map((action: string, i: number) => (
                <div key={i} className="flex items-start gap-3 text-sm">
                  <span className="text-green-400 mt-0.5 flex-shrink-0">&#10003;</span>
                  <span className="text-slate-300">{action}</span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Hourly forecast */}
        {briefing.hourly_forecast?.length > 0 && (
          <div className="bg-slate-800 rounded-xl p-4">
            <h2 className="font-semibold text-slate-200 mb-3">Tomorrow's Hourly Forecast</h2>
            <div className="space-y-2">
              {briefing.hourly_forecast.map((period: any, i: number) => (
                <div key={i} className="flex items-center justify-between text-sm py-2 border-b border-slate-700 last:border-0">
                  <span className="text-slate-400 w-24">{period.name}</span>
                  <span className="text-slate-200">{period.temp_f}&deg;F</span>
                  <span className="text-slate-300">{period.wind_mph} mph wind</span>
                  <span className="text-slate-400 text-xs flex-1 text-right">{period.forecast}</span>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
