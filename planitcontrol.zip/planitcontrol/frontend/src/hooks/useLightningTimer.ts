import { useState, useEffect } from 'react'

/**
 * Returns countdown in seconds to all_clear_at.
 * Recalculates every second. Survives page refresh (reads from ISO string).
 */
export function useLightningTimer(all_clear_at: string | null | undefined): number {
  const [remaining, setRemaining] = useState<number>(0)

  useEffect(() => {
    if (!all_clear_at) {
      setRemaining(0)
      return
    }

    const clearTime = new Date(all_clear_at).getTime()

    const tick = () => {
      const diff = Math.max(0, Math.floor((clearTime - Date.now()) / 1000))
      setRemaining(diff)
    }

    tick()
    const interval = setInterval(tick, 1000)
    return () => clearInterval(interval)
  }, [all_clear_at])

  return remaining
}
