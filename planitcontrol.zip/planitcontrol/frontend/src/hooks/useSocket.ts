import { useEffect } from 'react'
import { io, Socket } from 'socket.io-client'
import { useAlertStore } from '../store/useAlertStore'
import { useSiteStore } from '../store/useSiteStore'

const WS_URL = import.meta.env.VITE_WS_URL || 'http://localhost:8000'

let socket: Socket | null = null

export function useSocket() {
  const addOrUpdateAlert = useAlertStore((s) => s.addOrUpdateAlert)
  const clearAlert = useAlertStore((s) => s.clearAlert)
  const updateSiteRisk = useSiteStore((s) => s.updateSiteRisk)

  useEffect(() => {
    if (socket?.connected) return

    socket = io(WS_URL, {
      transports: ['polling', 'websocket'],
      reconnectionAttempts: 10,
      reconnectionDelay: 2000,
    })

    socket.on('connect', () => {
      console.log('Socket.io connected:', socket?.id)
      socket?.emit('join_dashboard', {})
    })

    socket.on('disconnect', () => {
      console.log('Socket.io disconnected')
    })

    socket.on('lightning_alert', (data: any) => {
      console.log('Lightning alert:', data)
      if (data.action === 'CLEARED') {
        clearAlert(data.plant_id, 'lightning')
      } else {
        addOrUpdateAlert({
          plant_id: data.plant_id,
          alert_type: 'lightning',
          type: 'lightning',
          action: data.action,
          all_clear_at: data.all_clear_at,
          strike_count: data.strike_count,
          status: 'active',
        })
      }
    })

    socket.on('risk_update', (data: any) => {
      updateSiteRisk(data.plant_id, data.risk_score, data.sub_scores)
    })

    socket.on('flood_warning', (data: any) => {
      addOrUpdateAlert({
        plant_id: data.plant_id,
        alert_type: 'flood',
        type: 'flood',
        status: 'active',
      })
    })

    return () => {
      // Don't disconnect on unmount — keep persistent connection
    }
  }, [])

  return socket
}

export function getSocket() {
  return socket
}
