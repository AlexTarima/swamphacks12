# PlanIT Control — Handoff Document

**Project:** SwampHacks 2024 submission
**Status:** Code complete, not yet run
**Location:** `C:\tmp\planitcontrol\`

---

## What This Is

A real-time environmental hazard monitoring platform for utility field crews. Supervisors get one dashboard that aggregates weather, lightning, flooding, and wildlife hazards across every power plant site, scored 0–10 by a GBM ML model. Lightning strikes trigger a 30-minute stop-work countdown that resets on each new strike. Crew members in the field submit hazard photos from their phone, which appear as pins on every supervisor's map in real time.

---

## Quickstart

**Requires Docker Desktop** — install from https://www.docker.com/products/docker-desktop/

```bash
cd C:\tmp\planitcontrol
docker-compose up
```

First boot takes ~3–5 minutes (image builds + pip install + npm install). On startup, the backend automatically:
1. Waits for PostgreSQL to be healthy
2. Seeds 51 real US power plants into the DB
3. Trains the GBM risk model (saves to `backend/app/ml/model.pkl`)
4. Starts the API server

| Service | URL |
|---------|-----|
| Frontend | http://localhost:5173 |
| API | http://localhost:8000 |
| Health check | http://localhost:8000/health |
| API docs | http://localhost:8000/docs |

---

## Architecture

```
┌─────────────────────────────────────────────────────┐
│  Browser                                            │
│  React 18 + Leaflet + Zustand + Socket.io-client   │
│  Vite dev server :5173                              │
└────────────────────┬────────────────────────────────┘
                     │ HTTP + WebSocket
┌────────────────────▼────────────────────────────────┐
│  FastAPI + python-socketio  :8000                   │
│  APScheduler (embedded, no Redis/Celery)            │
│  ├── weather_poller      every 5 min → NOAA API     │
│  ├── usgs_poller         every 15 min → USGS API    │
│  ├── alert_dispatcher    every 60s → clear expired  │
│  ├── lightning_watcher   persistent WS → Blitzortung│
│  └── briefing_generator  cron 18:00 UTC daily       │
└────────────────────┬────────────────────────────────┘
                     │ asyncpg
┌────────────────────▼────────────────────────────────┐
│  PostgreSQL 15 + PostGIS  :5432                     │
│  DB: planitcontrol                                  │
└─────────────────────────────────────────────────────┘
```

---

## File Map

```
planitcontrol/
├── docker-compose.yml
├── .env                        # DB creds + secret key (do not commit)
├── .env.example
│
├── backend/
│   ├── start.sh                # Entrypoint: seed → train → uvicorn
│   ├── requirements.txt
│   ├── Dockerfile
│   │
│   ├── app/
│   │   ├── main.py             # App factory, Socket.io mount, lifecycle hooks
│   │   ├── config.py           # Pydantic Settings (reads .env)
│   │   ├── database.py         # Async SQLAlchemy engine + get_db dependency
│   │   ├── scheduler.py        # APScheduler job registration
│   │   │
│   │   ├── models/             # SQLAlchemy ORM models
│   │   │   ├── plant.py        # Power plant with PostGIS POINT geometry
│   │   │   ├── hazard_snapshot.py  # Per-poll weather + all sub-scores
│   │   │   ├── alert.py        # Lightning/flood/heat alert lifecycle
│   │   │   ├── crew_report.py  # Field hazard reports with photo path
│   │   │   ├── briefing.py     # Daily safety briefing JSON
│   │   │   ├── risk_score.py   # Aggregated scores (currently unused, for future)
│   │   │   └── lightning_strike.py  # Raw strike log with PostGIS geometry
│   │   │
│   │   ├── routers/            # FastAPI route handlers
│   │   │   ├── sites.py        # GET /api/sites, GET /api/sites/{id}
│   │   │   ├── hazards.py      # GET /api/hazards/{id}/history
│   │   │   ├── alerts.py       # GET /api/alerts, POST /api/alerts/{id}/acknowledge
│   │   │   ├── crew.py         # POST /api/crew/reports (multipart), GET /api/crew/reports
│   │   │   ├── briefings.py    # GET /api/briefings/{site_id}/latest
│   │   │   └── dashboard.py    # GET /api/dashboard/ranked
│   │   │
│   │   ├── services/
│   │   │   ├── risk_engine.py      # All scoring functions (heat/lightning/flood/etc.)
│   │   │   ├── weather_poller.py   # NOAA NWS API, stores HazardSnapshot rows
│   │   │   ├── lightning_watcher.py # Blitzortung WS → PostGIS 10mi radius → alerts
│   │   │   ├── usgs_poller.py      # USGS stream gauge readings → flood score
│   │   │   ├── alert_dispatcher.py # Create/reset/clear Alert rows + Socket.io emit
│   │   │   └── briefing_generator.py # NWS 7-day forecast → structured daily briefing
│   │   │
│   │   └── ml/
│   │       ├── train.py        # Generates model.pkl (run once, or auto on boot)
│   │       ├── features.py     # extract_features() → numpy array for model input
│   │       └── predictor.py    # score() → 0-10; falls back to rule-based if no .pkl
│   │
│   └── data/
│       ├── seed_plants.py      # 51 US power plants → plants table (idempotent)
│       ├── run_seed.sh         # Helper: cd /app && python data/seed_plants.py
│       └── train_model.sh      # Helper: python -m app.ml.train
│
└── frontend/
    ├── package.json            # React 18, React-Leaflet, Zustand, Recharts, Socket.io
    ├── vite.config.ts          # Proxies /api and /socket.io to :8000
    ├── tailwind.config.js
    │
    └── src/
        ├── App.tsx             # Router, Nav, LightningBanner gate
        │
        ├── store/
        │   ├── useAlertStore.ts    # Active alerts, addOrUpdate, clear
        │   ├── useSiteStore.ts     # Sites array, updateSiteRisk (live patch)
        │   └── useMapStore.ts      # Map center/zoom/selected site
        │
        ├── hooks/
        │   ├── useSocket.ts        # Persistent Socket.io; handles lightning/risk/flood events
        │   └── useLightningTimer.ts # 1s countdown from ISO all_clear_at string
        │
        ├── pages/
        │   ├── MapView.tsx         # Full-screen dark Leaflet map, legend, site count
        │   ├── Dashboard.tsx       # Ranked cards, filter tabs, 30s auto-refresh
        │   ├── SiteDetail.tsx      # Conditions grid, sub-scores, history chart, briefing
        │   ├── CrewReporter.tsx    # Mobile-first: GPS → hazard type → photo → submit
        │   └── BriefingView.tsx    # Daily safety briefing with hazards + safety actions
        │
        └── components/
            ├── map/
            │   ├── SiteMarker.tsx      # Color-coded DivIcon, glow ring for high risk
            │   ├── CrewReportPin.tsx   # Emoji pin for crew reports, photo in popup
            │   └── LightningFlash.tsx  # Yellow CircleMarkers for live strike positions
            ├── alerts/
            │   ├── LightningBanner.tsx # Pulsing red stop-work banner with countdown
            │   └── FloodWarning.tsx    # Blue card, gauge vs flood-stage ratio
            ├── dashboard/
            │   ├── SiteRankCard.tsx    # Card with sub-score bars + RiskGauge
            │   └── RiskGauge.tsx       # Recharts radial gauge, color by tier
            └── shared/
                └── TimerBadge.tsx      # MM:SS monospace countdown display
```

---

## API Reference

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/health` | Service health check |
| GET | `/api/sites` | All plants with latest conditions + sub-scores |
| GET | `/api/sites/{id}` | Single plant + last 24 snapshots |
| GET | `/api/hazards/{id}/history` | Snapshot history (default 48 rows) |
| GET | `/api/alerts` | All active alerts |
| GET | `/api/alerts/{id}` | Alerts for a specific plant |
| POST | `/api/alerts/{id}/acknowledge` | Acknowledge an alert |
| GET | `/api/dashboard/ranked` | All plants sorted by risk score desc |
| POST | `/api/crew/reports` | Multipart: plant_id, reporter_name, hazard_type, notes, latitude, longitude, photo |
| GET | `/api/crew/reports` | Recent crew reports |
| GET | `/api/briefings/{id}/latest` | Latest daily briefing for a site |

---

## Socket.io Events

All events flow through a single Socket.io connection at the same port as the API (:8000).

**Client → Server:**
```js
socket.emit('join_dashboard')        // subscribe to all sites
socket.emit('join_site', {plant_id}) // subscribe to one site's room
```

**Server → Client:**
```js
// lightning_alert
{ plant_id, action: "NEW"|"RESET"|"CLEARED", all_clear_at: ISO string, strike_count }

// risk_update
{ plant_id, risk_score: 0-10, sub_scores: { heat, lightning, flood, wildfire, wind, wildlife } }

// flood_warning
{ plant_id, gauge_ft, flood_stage_ft, flood_score }

// crew_report_new
{ report_id, plant_id, lat, lon, type, reporter, notes, photo_path }
```

---

## Risk Scoring Logic

All logic lives in `backend/app/services/risk_engine.py`.

| Hazard | Key thresholds | Max score |
|--------|---------------|-----------|
| Heat | <91°F→0, 91–103→2, 103–115→5, >115→9, +1 if NWS Excessive Heat Warning | 10 |
| Lightning | Severe Thunderstorm Warning→7, strike within 10mi/30min→10 | 10 |
| Flood | gauge/flood_stage: <0.5→0, 0.75→2, 0.90→4, 1.0→7, >1.0→10 | 10 |
| Wildfire | Fire Weather Watch→5, Red Flag Warning→8 | 8 |
| Wind | <25mph→0, 25–35→2, 35–50→5, 50–65→7, >65→10 | 10 |
| Wildlife | 0 crew reports→0, 1→3, 2+→6 | 6 |

Combined index formula:
```
index = lightning*0.25 + heat*0.20 + flood*0.20 + wildfire*0.15 + wind*0.10 + wildlife*0.05
```

The ML model (`predictor.py`) wraps a `CalibratedClassifierCV(GradientBoostingClassifier)` trained on synthetic injury data. Its `predict_proba * 10` output replaces the formula above when `model.pkl` exists. If the .pkl is missing the rule-based formula runs transparently via the same `score()` interface.

---

## Data Sources (all free, no API keys)

| Source | What it provides | Polling |
|--------|-----------------|---------|
| `api.weather.gov` | Hourly forecasts, NWS alerts | Every 5 min |
| `waterservices.usgs.gov` | Stream gauge height (ft) | Every 15 min |
| `ws.blitzortung.org` | Global lightning strikes (WebSocket) | Real-time |
| Seed data | 51 plants from EIA-860M (hardcoded) | Once on boot |

---

## Known Issues / What Still Needs Work

### Must-fix before demo

1. **Docker not installed on host machine** — Docker Desktop must be installed and running before `docker-compose up` will work. Nothing runs without it.

2. **Blitzortung WebSocket protocol** — `lightning_watcher.py` implements the standard Blitzortung message format (`{"lat": ..., "lon": ...}` and legacy `{"x": ..., "y": ...}` with 1e6 scaling). The actual protocol may differ slightly; monitor backend logs on first run and adjust `parse_blitzortung_message()` in `backend/app/services/lightning_watcher.py:80` if strikes aren't being parsed.

3. **NWS grid coordinates not pre-populated** — Plants are seeded without `nws_office`/`nws_grid_x`/`nws_grid_y`. The first weather poll calls `GET /points/{lat},{lon}` to fill these in, but this means the first poll will be slow and NWS may rate-limit it for 51 plants. The poller batches in groups of 5 with a 1s pause; still, expect the first weather cycle to take 2–3 minutes.

4. **USGS gauge IDs not configured** — No plants in `seed_plants.py` have `usgs_gauge_id` set. Flood scores will fall back to NWS alert text ("Flash Flood Warning" etc.) rather than real gauge readings. To add a gauge: find the USGS site number at https://waterdata.usgs.gov, then `UPDATE plants SET usgs_gauge_id='XXXXXXXX', flood_stage_ft=20 WHERE name='...'`.

5. **Frontend `VITE_API_URL` in docker-compose** — Currently set to `http://localhost:8000`, which works when the browser is on the same machine as Docker. If demoing from a different device on the network, update this to the host machine's LAN IP (e.g., `http://192.168.1.x:8000`).

### Nice-to-have polish

6. **FEMA flood zone tile layer** — The plan called for FEMA NFHL ArcGIS tiles as an optional map overlay. Not yet implemented. To add: in `MapView.tsx`, add a second `<TileLayer>` pointing to `https://hazards.fema.gov/gis/nfhl/rest/services/public/NFHL/MapServer/tile/{z}/{y}/{x}` with opacity 0.4.

7. **Lightning strike dots on map** — `LightningFlash.tsx` is wired up but `flashes` state in `MapView.tsx` is never populated. To fix: add a `lightning_strike` Socket.io event from the backend emitting `{lat, lon}` when a strike is processed, then push it into `flashes` state with a 10-second TTL.

8. **Wildlife score from crew reports** — `risk_engine.wildlife_score()` is implemented but the weather poller doesn't query `crew_reports` to count recent wildlife sightings. To fix: in `weather_poller.py:poll_plant_weather()`, query `COUNT(crew_reports WHERE plant_id=X AND hazard_type='wildlife' AND reported_at > NOW()-1h` and pass the result to `compute_all_scores(recent_wildlife_reports=N)`.

9. **Alert acknowledgement in UI** — The `POST /api/alerts/{id}/acknowledge` endpoint exists but there's no button in the UI to call it. Add an "Acknowledge" button to `LightningBanner.tsx` and `SiteDetail.tsx`.

10. **No loading skeleton / error boundary** — MapView and Dashboard show a plain text "Loading..." state. Add a proper skeleton or spinner, and an `<ErrorBoundary>` wrapper in `App.tsx`.

11. **Mobile nav** — The top Nav bar wraps awkwardly on small screens. Consider adding a hamburger menu for the CrewReporter use case (phone in the field).

---

## Environment Variables

| Variable | Default | Description |
|----------|---------|-------------|
| `DATABASE_URL` | `postgresql+asyncpg://planituser:planitpass@db:5432/planitcontrol` | Async SQLAlchemy URL |
| `DATABASE_SYNC_URL` | same but `postgresql://` | Used by Alembic (not yet configured) |
| `SECRET_KEY` | `swamphacks-planitcontrol-2024` | Change for production |
| `UPLOAD_DIR` | `/app/data/uploads` | Photo upload storage |
| `WEATHER_POLL_INTERVAL` | `300` | Seconds between weather polls |
| `USGS_POLL_INTERVAL` | `900` | Seconds between gauge polls |
| `LIGHTNING_ALL_CLEAR_SECONDS` | `1800` | 30-min stop-work window |

All vars are read from `.env` via `backend/app/config.py` (Pydantic Settings).

---

## How to Test the Lightning Flow (Manual Demo)

With the app running, insert a test lightning strike near Turkey Point Nuclear (Miami):

```sql
-- Connect to DB
docker-compose exec db psql -U planituser -d planitcontrol

-- Insert a strike 5 miles from Turkey Point Nuclear (lat 25.4344, lon -80.3311)
INSERT INTO lightning_strikes (geom, struck_at)
VALUES (ST_MakePoint(-80.29, 25.44)::geography, NOW());
```

Then call the alert dispatcher manually via the API or simulate it by calling the internal function directly. A cleaner approach: add a test endpoint temporarily:

```python
# In backend/app/routers/sites.py (remove before production)
@router.post("/test/lightning")
async def test_lightning(lat: float, lon: float, request: Request, db = Depends(get_db)):
    from app.services.lightning_watcher import process_strike
    await process_strike(lat, lon, request.app.state.sio)
    return {"ok": True}
```

Then call:
```bash
curl -X POST "http://localhost:8000/api/test/lightning?lat=25.44&lon=-80.29"
```

The browser should immediately show the red lightning banner with a 30-minute countdown.

---

## Resuming with Claude Code

If you want to continue building this with Claude, copy this conversation context or point Claude at this file. The full implementation transcript is at:

```
C:\Users\HZhao\.claude\projects\C--tmp\c71c57d6-94da-42f5-87e8-287a25da5e0c.jsonl
```

Suggested prompt to continue:
> "Read HANDOFF.md in C:\tmp\planitcontrol, then help me fix the known issues listed there, starting with getting docker-compose up running."
