#!/bin/bash
set -e

echo "=== PlanIT Control Backend Startup ==="

# Wait for postgres
echo "Waiting for database..."
until python -c "
import asyncio, asyncpg, os
async def check():
    url = os.getenv('DATABASE_URL', '').replace('postgresql+asyncpg://', 'postgresql://')
    conn = await asyncpg.connect(url)
    await conn.close()
asyncio.run(check())
" 2>/dev/null; do
  echo "  DB not ready, retrying..."
  sleep 2
done
echo "Database ready!"

# Seed plants (idempotent — skips if already seeded)
echo "Seeding plants..."
cd /app
python data/seed_plants.py

# Train ML model if model.pkl doesn't exist
if [ ! -f /app/app/ml/model.pkl ]; then
  echo "Training ML model..."
  python -m app.ml.train
fi

echo "Starting uvicorn..."
exec uvicorn app.main:socket_app --host 0.0.0.0 --port 8000 --reload
