from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select

from app.database import get_db
from app.models.hazard_snapshot import HazardSnapshot
from app.models.lightning_strike import LightningStrike

router = APIRouter()


@router.get("/hazards/{site_id}/history")
async def get_hazard_history(site_id: int, limit: int = 48, db: AsyncSession = Depends(get_db)):
    result = await db.execute(
        select(HazardSnapshot)
        .where(HazardSnapshot.plant_id == site_id)
        .order_by(HazardSnapshot.recorded_at.desc())
        .limit(limit)
    )
    snapshots = result.scalars().all()
    return [
        {
            "recorded_at": s.recorded_at.isoformat() if s.recorded_at else None,
            "temp_f": s.temp_f,
            "wind_mph": s.wind_mph,
            "heat_index_f": s.heat_index_f,
            "heat_score": s.heat_score or 0,
            "lightning_score": s.lightning_score or 0,
            "flood_score": s.flood_score or 0,
            "wildfire_score": s.wildfire_score or 0,
            "wind_score": s.wind_score or 0,
            "ml_risk_index": s.ml_risk_index or 0,
        }
        for s in snapshots
    ]
