import os
import uuid
from fastapi import APIRouter, Depends, UploadFile, File, Form, Request
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
import aiofiles

from app.database import get_db
from app.models.crew_report import CrewReport
from app.models.plant import Plant
from app.config import get_settings

settings = get_settings()
router = APIRouter()


@router.post("/crew/reports")
async def submit_crew_report(
    request: Request,
    plant_id: int = Form(...),
    reporter_name: str = Form(...),
    hazard_type: str = Form(...),
    notes: str = Form(""),
    latitude: float = Form(None),
    longitude: float = Form(None),
    photo: UploadFile = File(None),
    db: AsyncSession = Depends(get_db),
):
    photo_path = None
    if photo and photo.filename:
        ext = os.path.splitext(photo.filename)[1] or ".jpg"
        filename = f"{uuid.uuid4()}{ext}"
        filepath = os.path.join(settings.upload_dir, filename)
        async with aiofiles.open(filepath, "wb") as f:
            content = await photo.read()
            await f.write(content)
        photo_path = f"/uploads/{filename}"

    geom = None
    if latitude is not None and longitude is not None:
        geom = f"SRID=4326;POINT({longitude} {latitude})"

    report = CrewReport(
        plant_id=plant_id,
        reporter_name=reporter_name,
        hazard_type=hazard_type,
        notes=notes,
        photo_path=photo_path,
        geom=geom,
        latitude=latitude,
        longitude=longitude,
    )
    db.add(report)
    await db.commit()
    await db.refresh(report)

    # Broadcast to supervisors
    sio = request.app.state.sio
    await sio.emit(
        "crew_report_new",
        {
            "report_id": report.id,
            "plant_id": plant_id,
            "lat": latitude,
            "lon": longitude,
            "type": hazard_type,
            "reporter": reporter_name,
            "notes": notes,
            "photo_path": photo_path,
        },
        room="dashboard",
    )

    return {"id": report.id, "status": "submitted"}


@router.get("/crew/reports")
async def get_crew_reports(limit: int = 50, db: AsyncSession = Depends(get_db)):
    result = await db.execute(
        select(CrewReport).order_by(CrewReport.reported_at.desc()).limit(limit)
    )
    reports = result.scalars().all()
    return [
        {
            "id": r.id,
            "plant_id": r.plant_id,
            "reporter_name": r.reporter_name,
            "hazard_type": r.hazard_type,
            "notes": r.notes,
            "photo_path": r.photo_path,
            "latitude": r.latitude,
            "longitude": r.longitude,
            "reported_at": r.reported_at.isoformat() if r.reported_at else None,
        }
        for r in reports
    ]
