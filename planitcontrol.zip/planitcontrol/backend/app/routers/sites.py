from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, text
from typing import List
import json

from app.database import get_db
from app.models.plant import Plant
from app.models.hazard_snapshot import HazardSnapshot

router = APIRouter()


@router.get("/sites")
async def get_sites(db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(Plant).order_by(Plant.name))
    plants = result.scalars().all()

    sites = []
    for plant in plants:
        # Get latest snapshot
        snap_result = await db.execute(
            select(HazardSnapshot)
            .where(HazardSnapshot.plant_id == plant.id)
            .order_by(HazardSnapshot.recorded_at.desc())
            .limit(1)
        )
        snapshot = snap_result.scalar_one_or_none()

        site_data = {
            "id": plant.id,
            "eia_plant_id": plant.eia_plant_id,
            "name": plant.name,
            "utility": plant.utility,
            "state": plant.state,
            "county": plant.county,
            "technology": plant.technology,
            "capacity_mw": plant.capacity_mw,
            "latitude": plant.latitude,
            "longitude": plant.longitude,
            "timezone": plant.timezone,
        }

        if snapshot:
            site_data["current_conditions"] = {
                "temp_f": snapshot.temp_f,
                "heat_index_f": snapshot.heat_index_f,
                "wind_mph": snapshot.wind_mph,
                "precip_in": snapshot.precip_in,
                "humidity_pct": snapshot.humidity_pct,
                "nws_alerts": snapshot.nws_alerts or [],
                "usgs_gauge_ft": snapshot.usgs_gauge_ft,
                "flood_stage_ft": snapshot.flood_stage_ft,
                "heat_score": snapshot.heat_score or 0,
                "lightning_score": snapshot.lightning_score or 0,
                "flood_score": snapshot.flood_score or 0,
                "wildfire_score": snapshot.wildfire_score or 0,
                "wind_score": snapshot.wind_score or 0,
                "wildlife_score": snapshot.wildlife_score or 0,
                "ml_risk_index": snapshot.ml_risk_index or 0,
                "recorded_at": snapshot.recorded_at.isoformat() if snapshot.recorded_at else None,
            }
        else:
            site_data["current_conditions"] = None

        sites.append(site_data)

    return sites


@router.get("/sites/{site_id}")
async def get_site(site_id: int, db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(Plant).where(Plant.id == site_id))
    plant = result.scalar_one_or_none()
    if not plant:
        raise HTTPException(status_code=404, detail="Site not found")

    # Get recent snapshots
    snaps_result = await db.execute(
        select(HazardSnapshot)
        .where(HazardSnapshot.plant_id == site_id)
        .order_by(HazardSnapshot.recorded_at.desc())
        .limit(24)
    )
    snapshots = snaps_result.scalars().all()

    return {
        "id": plant.id,
        "name": plant.name,
        "utility": plant.utility,
        "state": plant.state,
        "county": plant.county,
        "technology": plant.technology,
        "capacity_mw": plant.capacity_mw,
        "latitude": plant.latitude,
        "longitude": plant.longitude,
        "timezone": plant.timezone,
        "usgs_gauge_id": plant.usgs_gauge_id,
        "flood_stage_ft": plant.flood_stage_ft,
        "recent_snapshots": [
            {
                "recorded_at": s.recorded_at.isoformat() if s.recorded_at else None,
                "temp_f": s.temp_f,
                "heat_index_f": s.heat_index_f,
                "wind_mph": s.wind_mph,
                "precip_in": s.precip_in,
                "humidity_pct": s.humidity_pct,
                "heat_score": s.heat_score or 0,
                "lightning_score": s.lightning_score or 0,
                "flood_score": s.flood_score or 0,
                "wildfire_score": s.wildfire_score or 0,
                "wind_score": s.wind_score or 0,
                "wildlife_score": s.wildlife_score or 0,
                "ml_risk_index": s.ml_risk_index or 0,
                "nws_alerts": s.nws_alerts or [],
            }
            for s in snapshots
        ],
    }
