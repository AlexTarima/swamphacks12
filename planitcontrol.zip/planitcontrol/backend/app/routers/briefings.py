from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select

from app.database import get_db
from app.models.briefing import Briefing

router = APIRouter()


@router.get("/briefings/{site_id}/latest")
async def get_latest_briefing(site_id: int, db: AsyncSession = Depends(get_db)):
    result = await db.execute(
        select(Briefing)
        .where(Briefing.plant_id == site_id)
        .order_by(Briefing.generated_at.desc())
        .limit(1)
    )
    briefing = result.scalar_one_or_none()
    if not briefing:
        raise HTTPException(status_code=404, detail="No briefing found for this site")
    return {
        "id": briefing.id,
        "plant_id": briefing.plant_id,
        "generated_at": briefing.generated_at.isoformat() if briefing.generated_at else None,
        "briefing_date": briefing.briefing_date,
        "summary": briefing.summary,
        "hazards": briefing.hazards,
        "safety_actions": briefing.safety_actions,
        "hourly_forecast": briefing.hourly_forecast,
    }
