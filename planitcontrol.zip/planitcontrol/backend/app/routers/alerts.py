from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from datetime import datetime, timezone

from app.database import get_db
from app.models.alert import Alert

router = APIRouter()


@router.get("/alerts")
async def get_active_alerts(db: AsyncSession = Depends(get_db)):
    result = await db.execute(
        select(Alert)
        .where(Alert.status == "active")
        .order_by(Alert.triggered_at.desc())
    )
    alerts = result.scalars().all()
    return [
        {
            "id": a.id,
            "plant_id": a.plant_id,
            "alert_type": a.alert_type,
            "status": a.status,
            "triggered_at": a.triggered_at.isoformat() if a.triggered_at else None,
            "last_strike_at": a.last_strike_at.isoformat() if a.last_strike_at else None,
            "all_clear_at": a.all_clear_at.isoformat() if a.all_clear_at else None,
            "strike_count": a.strike_count,
            "metadata": a.metadata_,
        }
        for a in alerts
    ]


@router.get("/alerts/{site_id}")
async def get_site_alerts(site_id: int, db: AsyncSession = Depends(get_db)):
    result = await db.execute(
        select(Alert)
        .where(Alert.plant_id == site_id)
        .order_by(Alert.triggered_at.desc())
        .limit(20)
    )
    alerts = result.scalars().all()
    return [
        {
            "id": a.id,
            "plant_id": a.plant_id,
            "alert_type": a.alert_type,
            "status": a.status,
            "triggered_at": a.triggered_at.isoformat() if a.triggered_at else None,
            "all_clear_at": a.all_clear_at.isoformat() if a.all_clear_at else None,
            "strike_count": a.strike_count,
        }
        for a in alerts
    ]


@router.post("/alerts/{alert_id}/acknowledge")
async def acknowledge_alert(alert_id: int, db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(Alert).where(Alert.id == alert_id))
    alert = result.scalar_one_or_none()
    if not alert:
        raise HTTPException(status_code=404, detail="Alert not found")
    alert.status = "acknowledged"
    await db.commit()
    return {"status": "acknowledged"}
