from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select

from app.database import get_db
from app.models.plant import Plant
from app.models.hazard_snapshot import HazardSnapshot
from app.models.alert import Alert

router = APIRouter()


@router.get("/dashboard/ranked")
async def get_ranked_sites(db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(Plant).order_by(Plant.name))
    plants = result.scalars().all()

    ranked = []
    for plant in plants:
        snap_result = await db.execute(
            select(HazardSnapshot)
            .where(HazardSnapshot.plant_id == plant.id)
            .order_by(HazardSnapshot.recorded_at.desc())
            .limit(1)
        )
        snapshot = snap_result.scalar_one_or_none()

        active_alerts_result = await db.execute(
            select(Alert)
            .where(Alert.plant_id == plant.id, Alert.status == "active")
        )
        active_alerts = active_alerts_result.scalars().all()

        risk_score = 0.0
        sub_scores = {}
        if snapshot:
            risk_score = snapshot.ml_risk_index or 0.0
            sub_scores = {
                "heat": snapshot.heat_score or 0,
                "lightning": snapshot.lightning_score or 0,
                "flood": snapshot.flood_score or 0,
                "wildfire": snapshot.wildfire_score or 0,
                "wind": snapshot.wind_score or 0,
                "wildlife": snapshot.wildlife_score or 0,
            }

        ranked.append({
            "id": plant.id,
            "name": plant.name,
            "state": plant.state,
            "technology": plant.technology,
            "latitude": plant.latitude,
            "longitude": plant.longitude,
            "risk_score": risk_score,
            "sub_scores": sub_scores,
            "active_alerts": [
                {
                    "id": a.id,
                    "type": a.alert_type,
                    "all_clear_at": a.all_clear_at.isoformat() if a.all_clear_at else None,
                    "strike_count": a.strike_count,
                }
                for a in active_alerts
            ],
            "last_updated": snapshot.recorded_at.isoformat() if snapshot and snapshot.recorded_at else None,
        })

    ranked.sort(key=lambda x: x["risk_score"], reverse=True)
    return ranked
