"""
Risk scoring engine — converts raw sensor data into 0-10 sub-scores
and a combined ML risk index.
"""
from typing import Optional, List, Dict, Any
import math


def heat_score(temp_f: Optional[float], heat_index_f: Optional[float], nws_alerts: List[Dict]) -> float:
    """OSHA heat thresholds → 0-10 score."""
    hi = heat_index_f or temp_f or 70.0

    if hi < 91:
        score = 0.0
    elif hi < 103:
        score = 2.0
    elif hi < 115:
        score = 5.0
    else:
        score = 9.0

    # +1 if Excessive Heat Warning active
    for alert in nws_alerts:
        event = alert.get("event", "").lower()
        if "excessive heat" in event and "warning" in event:
            score = min(10.0, score + 1.0)
            break

    return round(score, 1)


def lightning_score(
    nws_alerts: List[Dict],
    has_recent_strike_10mi: bool = False,
) -> float:
    """Lightning risk 0-10."""
    # If actual recent strike in 10mi → critical
    if has_recent_strike_10mi:
        return 10.0

    max_score = 0.0
    for alert in nws_alerts:
        event = alert.get("event", "").lower()
        if "severe thunderstorm warning" in event:
            max_score = max(max_score, 7.0)
        elif "thunderstorm watch" in event or "thunderstorm warning" in event:
            max_score = max(max_score, 4.0)
        elif "tornado warning" in event:
            max_score = max(max_score, 8.0)

    return round(max_score, 1)


def flood_score(
    usgs_gauge_ft: Optional[float],
    flood_stage_ft: Optional[float],
    nws_alerts: List[Dict],
) -> float:
    """Flood risk 0-10."""
    # Gauge-based scoring
    if usgs_gauge_ft is not None and flood_stage_ft and flood_stage_ft > 0:
        ratio = usgs_gauge_ft / flood_stage_ft
        if ratio < 0.5:
            return 0.0
        elif ratio < 0.75:
            return 2.0
        elif ratio < 0.90:
            return 4.0
        elif ratio < 1.0:
            return 7.0
        else:
            return 10.0

    # Fallback: NWS alerts
    max_score = 0.0
    for alert in nws_alerts:
        event = alert.get("event", "").lower()
        if "flash flood warning" in event or "flood warning" in event:
            max_score = max(max_score, 7.0)
        elif "flash flood watch" in event or "flood watch" in event:
            max_score = max(max_score, 3.0)

    return round(max_score, 1)


def wildfire_score(nws_alerts: List[Dict]) -> float:
    """Wildfire risk 0-10 based on NWS alerts."""
    max_score = 0.0
    for alert in nws_alerts:
        event = alert.get("event", "").lower()
        if "red flag warning" in event:
            max_score = max(max_score, 8.0)
        elif "fire weather watch" in event:
            max_score = max(max_score, 5.0)
    return round(max_score, 1)


def wind_score(wind_mph: Optional[float]) -> float:
    """Wind risk 0-10."""
    if wind_mph is None:
        return 0.0

    w = wind_mph
    if w < 25:
        return 0.0
    elif w < 35:
        return 2.0
    elif w < 50:
        return 5.0
    elif w < 65:
        return 7.0
    else:
        return 10.0


def wildlife_score(recent_wildlife_reports: int) -> float:
    """Wildlife hazard score from crew reports."""
    if recent_wildlife_reports == 0:
        return 0.0
    elif recent_wildlife_reports == 1:
        return 3.0
    else:
        return 6.0


def combined_risk_index(
    h_score: float,
    l_score: float,
    f_score: float,
    wf_score: float,
    w_score: float,
    wl_score: float,
) -> float:
    """
    Weighted combination — used as rule-based fallback and as ML feature baseline.
    lightning*0.25 + heat*0.20 + flood*0.20 + wildfire*0.15 + wind*0.10 + wildfire*0.05 + wildlife*0.05
    """
    index = (
        l_score * 0.25
        + h_score * 0.20
        + f_score * 0.20
        + wf_score * 0.15
        + w_score * 0.10
        + wl_score * 0.05
        # saturation placeholder: 0.05 weight, set to 0 for now
        + 0.0 * 0.05
    )
    return round(min(10.0, index), 2)


def compute_all_scores(
    temp_f: Optional[float] = None,
    heat_index_f: Optional[float] = None,
    wind_mph: Optional[float] = None,
    nws_alerts: Optional[List[Dict]] = None,
    usgs_gauge_ft: Optional[float] = None,
    flood_stage_ft: Optional[float] = None,
    has_recent_strike_10mi: bool = False,
    recent_wildlife_reports: int = 0,
) -> Dict[str, float]:
    """Compute all sub-scores and combined index."""
    alerts = nws_alerts or []

    h = heat_score(temp_f, heat_index_f, alerts)
    l = lightning_score(alerts, has_recent_strike_10mi)
    f = flood_score(usgs_gauge_ft, flood_stage_ft, alerts)
    wf = wildfire_score(alerts)
    w = wind_score(wind_mph)
    wl = wildlife_score(recent_wildlife_reports)
    combined = combined_risk_index(h, l, f, wf, w, wl)

    return {
        "heat_score": h,
        "lightning_score": l,
        "flood_score": f,
        "wildfire_score": wf,
        "wind_score": w,
        "wildlife_score": wl,
        "ml_risk_index": combined,
    }
