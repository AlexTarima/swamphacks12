"""
Connects to Blitzortung WebSocket feed and processes lightning strikes.
Performs PostGIS radius queries to find affected plants.
"""
import asyncio
import json
import logging
import zlib
import struct
from datetime import datetime, timezone
from typing import Optional

import websockets
from sqlalchemy import select, text
import socketio

from app.database import AsyncSessionLocal
from app.models.plant import Plant
from app.models.lightning_strike import LightningStrike
from app.models.hazard_snapshot import HazardSnapshot
from app.services.alert_dispatcher import create_or_reset_lightning_alert

logger = logging.getLogger(__name__)

BLITZORTUNG_URL = "wss://ws.blitzortung.org/wss/"
RECONNECT_DELAY = 5  # seconds
TEN_MILES_METERS = 16093


async def find_plants_near_strike(lat: float, lon: float) -> list:
    """PostGIS query — find plants within 10 miles of a strike."""
    async with AsyncSessionLocal() as db:
        result = await db.execute(
            text("""
                SELECT id, name
                FROM plants
                WHERE ST_DWithin(
                    geom::geography,
                    ST_MakePoint(:lon, :lat)::geography,
                    :radius_meters
                )
            """),
            {"lat": lat, "lon": lon, "radius_meters": TEN_MILES_METERS},
        )
        return result.fetchall()


async def store_strike(lat: float, lon: float):
    """Persist lightning strike to DB."""
    async with AsyncSessionLocal() as db:
        strike = LightningStrike(
            geom=f"SRID=4326;POINT({lon} {lat})",
            struck_at=datetime.now(timezone.utc),
        )
        db.add(strike)
        await db.commit()


async def process_strike(lat: float, lon: float, sio):
    """Handle a single lightning strike event."""
    await store_strike(lat, lon)
    nearby_plants = await find_plants_near_strike(lat, lon)

    if nearby_plants:
        logger.info(f"Strike at {lat:.3f},{lon:.3f} near {len(nearby_plants)} plant(s)")
        async with AsyncSessionLocal() as db:
            for plant_row in nearby_plants:
                plant_id = plant_row[0]
                plant_name = plant_row[1]
                logger.info(f"  → Alerting plant: {plant_name}")

                await create_or_reset_lightning_alert(db, plant_id, sio, lat, lon)

                # Update lightning score in latest snapshot
                snap_result = await db.execute(
                    select(HazardSnapshot)
                    .where(HazardSnapshot.plant_id == plant_id)
                    .order_by(HazardSnapshot.recorded_at.desc())
                    .limit(1)
                )
                snapshot = snap_result.scalar_one_or_none()
                if snapshot:
                    snapshot.lightning_score = 10.0
                    # Recalculate combined index
                    from app.services.risk_engine import combined_risk_index
                    snapshot.ml_risk_index = combined_risk_index(
                        snapshot.heat_score or 0,
                        10.0,
                        snapshot.flood_score or 0,
                        snapshot.wildfire_score or 0,
                        snapshot.wind_score or 0,
                        snapshot.wildlife_score or 0,
                    )
                    await db.commit()


def parse_blitzortung_message(raw_data) -> Optional[tuple]:
    """
    Parse Blitzortung WebSocket message.
    Returns (lat, lon) tuple or None.
    """
    try:
        if isinstance(raw_data, bytes):
            # Try decompressing
            try:
                raw_data = zlib.decompress(raw_data, -zlib.MAX_WBITS)
            except Exception:
                pass
            raw_data = raw_data.decode("utf-8", errors="replace")

        data = json.loads(raw_data)

        # Blitzortung format: {"lat": ..., "lon": ...}
        # or legacy: {"time": ..., "lat": ..., "lon": ...}
        if "lat" in data and "lon" in data:
            lat = float(data["lat"])
            lon = float(data["lon"])
            return (lat, lon)

        # Some formats use different keys
        if "x" in data and "y" in data:
            # x = lon * 1e6, y = lat * 1e6 (common in older feeds)
            lon = data["x"] / 1e6
            lat = data["y"] / 1e6
            return (lat, lon)

    except Exception:
        pass
    return None


async def start_lightning_watcher(sio):
    """Persistent WebSocket connection to Blitzortung with auto-reconnect."""
    logger.info("Starting lightning watcher...")

    while True:
        try:
            async with websockets.connect(
                BLITZORTUNG_URL,
                ping_interval=20,
                ping_timeout=10,
                open_timeout=15,
                close_timeout=5,
            ) as ws:
                logger.info("Connected to Blitzortung WebSocket")

                # Subscribe to global feed
                await ws.send(json.dumps({"a": 111}))

                async for message in ws:
                    coords = parse_blitzortung_message(message)
                    if coords:
                        lat, lon = coords
                        # Filter valid coordinates
                        if -90 <= lat <= 90 and -180 <= lon <= 180:
                            asyncio.create_task(process_strike(lat, lon, sio))

        except asyncio.CancelledError:
            logger.info("Lightning watcher cancelled")
            break
        except Exception as e:
            logger.warning(f"Lightning watcher disconnected: {e}, reconnecting in {RECONNECT_DELAY}s...")
            await asyncio.sleep(RECONNECT_DELAY)
