"""
Generates daily 6 PM safety briefings for each plant site.
"""
import asyncio
import httpx
import logging
from datetime import datetime, timezone, timedelta, date

from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select

from app.database import AsyncSessionLocal
from app.models.plant import Plant
from app.models.briefing import Briefing
from app.models.hazard_snapshot import HazardSnapshot

logger = logging.getLogger(__name__)

NOAA_BASE = "https://api.weather.gov"

SAFETY_TEMPLATES = {
    "lightning": [
        "Stop all outdoor work immediately if thunder is heard",
        "Move crews to substantial buildings or metal-roofed vehicles",
        "Wait 30 minutes after last thunder before resuming work",
        "Avoid contact with electrical equipment and metal objects",
    ],
    "heat": [
        "Mandatory hydration breaks every 15-20 minutes",
        "Buddy system required — watch for heat exhaustion symptoms",
        "Establish cool rest areas with shade and water",
        "Adjust work schedule to avoid peak heat (10am-4pm if possible)",
    ],
    "flood": [
        "Do not enter flooded areas or approach swollen waterways",
        "Monitor USGS gauge readings every 30 minutes",
        "Pre-position equipment above flood stage",
        "Establish evacuation route before work begins",
    ],
    "wind": [
        "Secure all loose materials and equipment",
        "Suspend crane and aerial lift operations above 35 mph",
        "Inspect rigging and temporary structures before use",
    ],
    "general": [
        "Check in with site supervisor every 2 hours",
        "Keep emergency contacts accessible",
        "Report any new hazards immediately via PlanIT Control app",
    ],
}


async def fetch_7day_forecast(client: httpx.AsyncClient, plant: Plant) -> dict:
    """Fetch 7-day NWS forecast for a plant."""
    if not plant.nws_office or plant.nws_grid_x is None:
        return {}

    try:
        url = f"{NOAA_BASE}/gridpoints/{plant.nws_office}/{plant.nws_grid_x},{plant.nws_grid_y}/forecast"
        resp = await client.get(url, timeout=15.0)
        if resp.status_code == 200:
            return resp.json()
    except Exception as e:
        logger.debug(f"Forecast fetch error for {plant.name}: {e}")
    return {}


def build_briefing(plant: Plant, forecast: dict, snapshot: HazardSnapshot | None) -> dict:
    """Assemble a structured daily briefing."""
    tomorrow = (date.today() + timedelta(days=1)).isoformat()
    hazards = []
    safety_actions = list(SAFETY_TEMPLATES["general"])
    hourly_forecast = []
    summary_parts = []

    periods = forecast.get("properties", {}).get("periods", [])

    # Extract tomorrow's periods
    tomorrow_periods = [p for p in periods if tomorrow in p.get("startTime", "")]
    if not tomorrow_periods:
        tomorrow_periods = periods[:4]  # fallback to next 4 periods

    for period in tomorrow_periods:
        temp = period.get("temperature", 80)
        wind_str = period.get("windSpeed", "0 mph")
        wind_val = float(wind_str.split()[0]) if wind_str else 0
        forecast_str = period.get("shortForecast", "").lower()

        hourly_forecast.append({
            "name": period.get("name"),
            "start": period.get("startTime"),
            "temp_f": temp,
            "wind_mph": wind_val,
            "forecast": period.get("shortForecast"),
        })

        if "thunder" in forecast_str:
            if "lightning" not in hazards:
                hazards.append("lightning")
                safety_actions.extend(SAFETY_TEMPLATES["lightning"])
        if "flood" in forecast_str:
            if "flood" not in hazards:
                hazards.append("flood")
                safety_actions.extend(SAFETY_TEMPLATES["flood"])
        if temp > 95:
            if "heat" not in hazards:
                hazards.append("heat")
                safety_actions.extend(SAFETY_TEMPLATES["heat"])
        if wind_val > 35:
            if "wind" not in hazards:
                hazards.append("wind")
                safety_actions.extend(SAFETY_TEMPLATES["wind"])

    if snapshot:
        if snapshot.ml_risk_index and snapshot.ml_risk_index >= 7:
            summary_parts.append(f"HIGH RISK conditions detected (score: {snapshot.ml_risk_index:.1f}/10)")
        elif snapshot.ml_risk_index and snapshot.ml_risk_index >= 4:
            summary_parts.append(f"MODERATE RISK conditions (score: {snapshot.ml_risk_index:.1f}/10)")

    if hazards:
        summary_parts.append(f"Tomorrow's forecast indicates: {', '.join(hazards)} hazards")
    else:
        summary_parts.append("Tomorrow's conditions appear favorable for outdoor work")

    summary = ". ".join(summary_parts) + "."

    return {
        "briefing_date": tomorrow,
        "summary": summary,
        "hazards": hazards,
        "safety_actions": list(dict.fromkeys(safety_actions)),  # deduplicate
        "hourly_forecast": hourly_forecast[:8],
        "raw_forecast": forecast,
    }


async def generate_daily_briefings(sio=None):
    """Generate briefings for all plants."""
    logger.info("Generating daily briefings...")

    async with AsyncSessionLocal() as db:
        result = await db.execute(select(Plant))
        plants = result.scalars().all()

        async with httpx.AsyncClient(
            headers={"User-Agent": "PlanITControl/1.0 (swamphacks@example.com)"}
        ) as client:
            for plant in plants:
                try:
                    forecast = await fetch_7day_forecast(client, plant)

                    snap_result = await db.execute(
                        select(HazardSnapshot)
                        .where(HazardSnapshot.plant_id == plant.id)
                        .order_by(HazardSnapshot.recorded_at.desc())
                        .limit(1)
                    )
                    snapshot = snap_result.scalar_one_or_none()

                    briefing_data = build_briefing(plant, forecast, snapshot)

                    briefing = Briefing(
                        plant_id=plant.id,
                        **briefing_data,
                    )
                    db.add(briefing)
                    await db.commit()

                    logger.info(f"Generated briefing for {plant.name}")
                except Exception as e:
                    logger.error(f"Error generating briefing for {plant.name}: {e}")

    logger.info("Daily briefings complete")
