"""
Polls USGS Water Services for stream gauge readings.
"""
import httpx
import logging
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, update

from app.database import AsyncSessionLocal
from app.models.plant import Plant
from app.models.hazard_snapshot import HazardSnapshot
from app.services.risk_engine import flood_score

logger = logging.getLogger(__name__)

USGS_BASE = "https://waterservices.usgs.gov/nwis/iv/"


async def fetch_gauge_reading(client: httpx.AsyncClient, gauge_id: str) -> float | None:
    """Fetch current stream gauge height in feet."""
    try:
        params = {
            "format": "json",
            "sites": gauge_id,
            "parameterCd": "00065",  # Gage height
            "siteStatus": "active",
        }
        resp = await client.get(USGS_BASE, params=params, timeout=15.0)
        if resp.status_code == 200:
            data = resp.json()
            series = data.get("value", {}).get("timeSeries", [])
            if series:
                values = series[0].get("values", [{}])[0].get("value", [])
                if values:
                    return float(values[-1].get("value", 0))
    except Exception as e:
        logger.debug(f"USGS error for gauge {gauge_id}: {e}")
    return None


async def poll_all_gauges(sio=None):
    """Update gauge readings for plants that have USGS gauge IDs."""
    logger.info("Starting USGS gauge poll...")
    async with AsyncSessionLocal() as db:
        result = await db.execute(
            select(Plant).where(Plant.usgs_gauge_id.isnot(None))
        )
        plants = result.scalars().all()

        if not plants:
            logger.info("No plants with USGS gauges configured")
            return

        async with httpx.AsyncClient() as client:
            for plant in plants:
                gauge_ft = await fetch_gauge_reading(client, plant.usgs_gauge_id)
                if gauge_ft is None:
                    continue

                f_score = flood_score(gauge_ft, plant.flood_stage_ft, [])

                # Update latest snapshot with gauge reading
                snap_result = await db.execute(
                    select(HazardSnapshot)
                    .where(HazardSnapshot.plant_id == plant.id)
                    .order_by(HazardSnapshot.recorded_at.desc())
                    .limit(1)
                )
                snapshot = snap_result.scalar_one_or_none()
                if snapshot:
                    snapshot.usgs_gauge_ft = gauge_ft
                    snapshot.flood_stage_ft = plant.flood_stage_ft
                    snapshot.flood_score = f_score
                    await db.commit()

                if sio and f_score >= 3.0:
                    await sio.emit(
                        "flood_warning",
                        {
                            "plant_id": plant.id,
                            "gauge_ft": gauge_ft,
                            "flood_stage_ft": plant.flood_stage_ft,
                            "flood_score": f_score,
                        },
                        room=f"site_{plant.id}",
                    )

    logger.info("USGS gauge poll complete")
