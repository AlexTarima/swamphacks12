"""
Creates, updates, and clears lightning/flood/heat alerts.
"""
import logging
from datetime import datetime, timezone, timedelta
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select

from app.database import AsyncSessionLocal
from app.models.alert import Alert
from app.config import get_settings

settings = get_settings()
logger = logging.getLogger(__name__)


async def create_or_reset_lightning_alert(
    db: AsyncSession,
    plant_id: int,
    sio,
    strike_lat: float,
    strike_lon: float,
) -> Alert:
    """Create new lightning alert or reset timer if one already exists."""
    now = datetime.now(timezone.utc)
    all_clear_at = now + timedelta(seconds=settings.lightning_all_clear_seconds)

    # Check for existing active alert
    result = await db.execute(
        select(Alert).where(
            Alert.plant_id == plant_id,
            Alert.alert_type == "lightning",
            Alert.status == "active",
        )
    )
    alert = result.scalar_one_or_none()

    if alert:
        # Reset timer
        alert.all_clear_at = all_clear_at
        alert.last_strike_at = now
        alert.strike_count = (alert.strike_count or 0) + 1
        await db.commit()
        action = "RESET"
    else:
        # New alert
        alert = Alert(
            plant_id=plant_id,
            alert_type="lightning",
            status="active",
            triggered_at=now,
            last_strike_at=now,
            all_clear_at=all_clear_at,
            strike_count=1,
            metadata_={"lat": strike_lat, "lon": strike_lon},
        )
        db.add(alert)
        await db.commit()
        await db.refresh(alert)
        action = "NEW"

    # Emit Socket.io event
    if sio:
        await sio.emit(
            "lightning_alert",
            {
                "plant_id": plant_id,
                "action": action,
                "all_clear_at": all_clear_at.isoformat(),
                "strike_count": alert.strike_count,
            },
            room="global_alerts",
        )
        await sio.emit(
            "lightning_alert",
            {
                "plant_id": plant_id,
                "action": action,
                "all_clear_at": all_clear_at.isoformat(),
                "strike_count": alert.strike_count,
            },
            room=f"site_{plant_id}",
        )

    return alert


async def cleanup_expired_alerts(sio=None):
    """Clear alerts that have passed their all_clear_at window."""
    now = datetime.now(timezone.utc)

    async with AsyncSessionLocal() as db:
        result = await db.execute(
            select(Alert).where(
                Alert.status == "active",
                Alert.all_clear_at <= now,
            )
        )
        expired = result.scalars().all()

        for alert in expired:
            alert.status = "cleared"
            if sio:
                await sio.emit(
                    "lightning_alert",
                    {
                        "plant_id": alert.plant_id,
                        "action": "CLEARED",
                        "all_clear_at": None,
                        "strike_count": alert.strike_count,
                    },
                    room="global_alerts",
                )

        if expired:
            await db.commit()
            logger.info(f"Cleared {len(expired)} expired alerts")
