"""
Polls NOAA Weather API for all plants every 5 minutes.
"""
import asyncio
import httpx
import logging
from datetime import datetime, timezone
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
import socketio

from app.database import AsyncSessionLocal
from app.models.plant import Plant
from app.models.hazard_snapshot import HazardSnapshot
from app.services.risk_engine import compute_all_scores

logger = logging.getLogger(__name__)

NOAA_BASE = "https://api.weather.gov"


async def fetch_nws_gridpoint(client: httpx.AsyncClient, plant: Plant):
    """Fetch weather observation from NWS gridpoint forecast."""
    if not plant.nws_office or plant.nws_grid_x is None or plant.nws_grid_y is None:
        return None

    try:
        url = f"{NOAA_BASE}/gridpoints/{plant.nws_office}/{plant.nws_grid_x},{plant.nws_grid_y}/forecast/hourly"
        resp = await client.get(url, timeout=15.0)
        if resp.status_code == 200:
            data = resp.json()
            periods = data.get("properties", {}).get("periods", [])
            if periods:
                p = periods[0]  # current hour
                return {
                    "temp_f": p.get("temperature"),
                    "wind_mph": _parse_wind(p.get("windSpeed", "0 mph")),
                    "precip_in": 0.0,
                    "humidity_pct": p.get("relativeHumidity", {}).get("value"),
                    "short_forecast": p.get("shortForecast", ""),
                }
    except Exception as e:
        logger.debug(f"NWS gridpoint error for {plant.name}: {e}")
    return None


async def fetch_nws_point_metadata(client: httpx.AsyncClient, lat: float, lon: float):
    """Get NWS office and grid coordinates for a lat/lon."""
    try:
        url = f"{NOAA_BASE}/points/{lat:.4f},{lon:.4f}"
        resp = await client.get(url, timeout=10.0)
        if resp.status_code == 200:
            props = resp.json().get("properties", {})
            return {
                "office": props.get("cwa"),
                "grid_x": props.get("gridX"),
                "grid_y": props.get("gridY"),
                "forecast_zone": props.get("forecastZone"),
            }
    except Exception as e:
        logger.debug(f"NWS points error for {lat},{lon}: {e}")
    return None


async def fetch_nws_alerts(client: httpx.AsyncClient, lat: float, lon: float):
    """Fetch active NWS alerts for a point."""
    try:
        url = f"{NOAA_BASE}/alerts/active?point={lat:.4f},{lon:.4f}"
        resp = await client.get(url, timeout=10.0)
        if resp.status_code == 200:
            features = resp.json().get("features", [])
            return [
                {
                    "id": f.get("id"),
                    "event": f.get("properties", {}).get("event", ""),
                    "headline": f.get("properties", {}).get("headline", ""),
                    "severity": f.get("properties", {}).get("severity", ""),
                    "effective": f.get("properties", {}).get("effective", ""),
                    "expires": f.get("properties", {}).get("expires", ""),
                }
                for f in features
            ]
    except Exception as e:
        logger.debug(f"NWS alerts error for {lat},{lon}: {e}")
    return []


def _parse_wind(wind_str: str) -> float:
    """Parse '15 mph' → 15.0"""
    try:
        parts = wind_str.split()
        return float(parts[0])
    except Exception:
        return 0.0


def _heat_index(temp_f: float, humidity: float) -> float:
    """Steadman heat index formula."""
    if temp_f < 80:
        return temp_f
    try:
        T = temp_f
        R = humidity
        HI = (-42.379 + 2.04901523*T + 10.14333127*R
              - 0.22475541*T*R - 0.00683783*T*T
              - 0.05481717*R*R + 0.00122874*T*T*R
              + 0.00085282*T*R*R - 0.00000199*T*T*R*R)
        return round(HI, 1)
    except Exception:
        return temp_f


async def poll_plant_weather(client: httpx.AsyncClient, plant: Plant, db: AsyncSession, sio):
    """Fetch weather + alerts + compute scores for one plant."""
    try:
        lat = plant.latitude
        lon = plant.longitude

        # Ensure we have NWS grid info
        if not plant.nws_office and lat and lon:
            meta = await fetch_nws_point_metadata(client, lat, lon)
            if meta:
                plant.nws_office = meta.get("office")
                plant.nws_grid_x = meta.get("grid_x")
                plant.nws_grid_y = meta.get("grid_y")
                await db.commit()

        # Fetch weather
        weather = await fetch_nws_gridpoint(client, plant)
        alerts = await fetch_nws_alerts(client, lat, lon)

        if not weather:
            # Use synthetic data for demo if API unavailable
            import random
            weather = {
                "temp_f": round(random.uniform(75, 98), 1),
                "wind_mph": round(random.uniform(5, 30), 1),
                "precip_in": round(random.uniform(0, 0.5), 2),
                "humidity_pct": round(random.uniform(50, 95), 1),
            }

        temp = weather.get("temp_f", 85.0)
        humidity = weather.get("humidity_pct", 70.0)
        heat_idx = _heat_index(temp, humidity or 70)

        scores = compute_all_scores(
            temp_f=temp,
            heat_index_f=heat_idx,
            wind_mph=weather.get("wind_mph"),
            nws_alerts=alerts,
        )

        snapshot = HazardSnapshot(
            plant_id=plant.id,
            temp_f=temp,
            heat_index_f=heat_idx,
            wind_mph=weather.get("wind_mph"),
            precip_in=weather.get("precip_in"),
            humidity_pct=humidity,
            nws_alerts=alerts,
            **scores,
        )
        db.add(snapshot)
        await db.commit()

        # Emit real-time update
        if sio:
            await sio.emit(
                "risk_update",
                {
                    "plant_id": plant.id,
                    "risk_score": scores["ml_risk_index"],
                    "sub_scores": {
                        "heat": scores["heat_score"],
                        "lightning": scores["lightning_score"],
                        "flood": scores["flood_score"],
                        "wildfire": scores["wildfire_score"],
                        "wind": scores["wind_score"],
                        "wildlife": scores["wildlife_score"],
                    },
                },
                room="dashboard",
            )

    except Exception as e:
        logger.error(f"Error polling weather for {plant.name}: {e}")


async def poll_all_weather(sio=None):
    """Poll weather for all plants."""
    logger.info("Starting weather poll...")
    async with AsyncSessionLocal() as db:
        result = await db.execute(select(Plant))
        plants = result.scalars().all()

        async with httpx.AsyncClient(headers={"User-Agent": "PlanITControl/1.0 (swamphacks@example.com)"}) as client:
            # Batch in groups of 5 to avoid rate limiting
            for i in range(0, len(plants), 5):
                batch = plants[i:i+5]
                tasks = [poll_plant_weather(client, plant, db, sio) for plant in batch]
                await asyncio.gather(*tasks, return_exceptions=True)
                await asyncio.sleep(1.0)  # brief pause between batches

    logger.info("Weather poll complete")
