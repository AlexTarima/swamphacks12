from pydantic_settings import BaseSettings
from functools import lru_cache


class Settings(BaseSettings):
    database_url: str = "postgresql+asyncpg://planituser:planitpass@localhost:5432/planitcontrol"
    database_sync_url: str = "postgresql://planituser:planitpass@localhost:5432/planitcontrol"
    secret_key: str = "changeme"
    upload_dir: str = "/app/data/uploads"

    # Polling intervals (seconds)
    weather_poll_interval: int = 300      # 5 min
    usgs_poll_interval: int = 900         # 15 min
    alert_cleanup_interval: int = 60      # 1 min

    # Lightning alert window (seconds)
    lightning_all_clear_seconds: int = 1800  # 30 min

    # Blitzortung WebSocket
    blitzortung_ws_url: str = "wss://ws.blitzortung.org/wss/"

    class Config:
        env_file = ".env"


@lru_cache()
def get_settings() -> Settings:
    return Settings()
