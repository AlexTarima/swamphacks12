import asyncio
from apscheduler.schedulers.asyncio import AsyncIOScheduler
from apscheduler.triggers.cron import CronTrigger
from apscheduler.triggers.interval import IntervalTrigger
import socketio

from app.config import get_settings

settings = get_settings()
_scheduler = None


async def start_scheduler(sio: socketio.AsyncServer):
    global _scheduler

    # Delay imports to avoid circular deps
    from app.services.weather_poller import poll_all_weather
    from app.services.usgs_poller import poll_all_gauges
    from app.services.alert_dispatcher import cleanup_expired_alerts
    from app.services.lightning_watcher import start_lightning_watcher
    from app.services.briefing_generator import generate_daily_briefings

    _scheduler = AsyncIOScheduler(timezone="UTC")

    # Weather polling every 5 min
    _scheduler.add_job(
        poll_all_weather,
        IntervalTrigger(seconds=settings.weather_poll_interval),
        args=[sio],
        id="weather_poll",
        replace_existing=True,
        max_instances=1,
    )

    # USGS gauge polling every 15 min
    _scheduler.add_job(
        poll_all_gauges,
        IntervalTrigger(seconds=settings.usgs_poll_interval),
        args=[sio],
        id="usgs_poll",
        replace_existing=True,
        max_instances=1,
    )

    # Alert cleanup every 60s
    _scheduler.add_job(
        cleanup_expired_alerts,
        IntervalTrigger(seconds=settings.alert_cleanup_interval),
        args=[sio],
        id="alert_cleanup",
        replace_existing=True,
        max_instances=1,
    )

    # Daily briefings at 18:00 UTC
    _scheduler.add_job(
        generate_daily_briefings,
        CronTrigger(hour=18, minute=0),
        args=[sio],
        id="daily_briefing",
        replace_existing=True,
    )

    _scheduler.start()

    # Start lightning watcher as background task
    asyncio.create_task(start_lightning_watcher(sio))

    # Run initial polls
    asyncio.create_task(poll_all_weather(sio))
    asyncio.create_task(poll_all_gauges(sio))

    print("Scheduler started")
