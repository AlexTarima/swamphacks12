import asyncio
import socketio
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
import os

from app.config import get_settings
from app.database import engine, Base
from app.routers import sites, hazards, alerts, crew, briefings, dashboard
from app.scheduler import start_scheduler

settings = get_settings()

# Socket.io server
sio = socketio.AsyncServer(
    async_mode="asgi",
    cors_allowed_origins="*",
    logger=False,
    engineio_logger=False,
)

# FastAPI app
app = FastAPI(title="PlanIT Control API", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include routers
app.include_router(sites.router, prefix="/api")
app.include_router(hazards.router, prefix="/api")
app.include_router(alerts.router, prefix="/api")
app.include_router(crew.router, prefix="/api")
app.include_router(briefings.router, prefix="/api")
app.include_router(dashboard.router, prefix="/api")

# Static files for uploads
os.makedirs(settings.upload_dir, exist_ok=True)
app.mount("/uploads", StaticFiles(directory=settings.upload_dir), name="uploads")


@app.get("/health")
async def health():
    return {"status": "ok", "service": "PlanIT Control"}


# Socket.io event handlers
@sio.event
async def connect(sid, environ):
    print(f"Client connected: {sid}")


@sio.event
async def disconnect(sid):
    print(f"Client disconnected: {sid}")


@sio.event
async def join_site(sid, data):
    plant_id = data.get("plant_id")
    if plant_id:
        await sio.enter_room(sid, f"site_{plant_id}")
        print(f"Client {sid} joined site_{plant_id}")


@sio.event
async def join_dashboard(sid, data):
    await sio.enter_room(sid, "dashboard")
    await sio.enter_room(sid, "global_alerts")
    print(f"Client {sid} joined dashboard")


@app.on_event("startup")
async def startup():
    async with engine.begin() as conn:
        # Create tables (in production use Alembic)
        await conn.run_sync(Base.metadata.create_all)

    os.makedirs(settings.upload_dir, exist_ok=True)

    # Start background scheduler
    await start_scheduler(sio)


@app.on_event("shutdown")
async def shutdown():
    await engine.dispose()


# Mount Socket.io on the FastAPI app
socket_app = socketio.ASGIApp(sio, other_asgi_app=app)

# Make sio accessible to services
app.state.sio = sio
