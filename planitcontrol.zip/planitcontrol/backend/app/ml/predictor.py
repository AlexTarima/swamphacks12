"""
ML predictor — loads model.pkl if available, falls back to rule-based engine.
Exposes a single score() method that returns a 0-10 risk index.
"""
import os
import logging
from pathlib import Path

logger = logging.getLogger(__name__)

MODEL_PATH = Path(__file__).parent / "model.pkl"
_model = None
_model_type = "rule-based"


def _load_model():
    global _model, _model_type
    if MODEL_PATH.exists():
        try:
            import joblib
            _model = joblib.load(MODEL_PATH)
            _model_type = "GBM (scikit-learn)"
            logger.info(f"Loaded ML model from {MODEL_PATH}")
        except Exception as e:
            logger.warning(f"Failed to load model.pkl: {e}, using rule-based fallback")
            _model = None
            _model_type = "Rule-Based Risk Engine v1"
    else:
        logger.info("No model.pkl found, using Rule-Based Risk Engine v1")
        _model_type = "Rule-Based Risk Engine v1"


_load_model()


def get_model_type() -> str:
    return _model_type


def score(
    temp_f=None,
    heat_index_f=None,
    wind_mph=None,
    precip_in=None,
    humidity_pct=None,
    nws_alerts=None,
    heat_score=0.0,
    lightning_score=0.0,
    flood_score=0.0,
    wildfire_score=0.0,
    wind_score=0.0,
    wildlife_score=0.0,
) -> float:
    """Return a 0-10 risk score."""
    if _model is not None:
        try:
            from app.ml.features import extract_features
            X = extract_features(
                temp_f=temp_f,
                heat_index_f=heat_index_f,
                wind_mph=wind_mph,
                precip_in=precip_in,
                humidity_pct=humidity_pct,
                nws_alerts=nws_alerts,
                heat_score=heat_score,
                lightning_score=lightning_score,
                flood_score=flood_score,
                wildfire_score=wildfire_score,
                wind_score=wind_score,
                wildlife_score=wildlife_score,
            )
            prob = _model.predict_proba(X)[0][1]
            return round(min(10.0, prob * 10), 2)
        except Exception as e:
            logger.warning(f"ML prediction failed: {e}, using rule-based")

    # Rule-based fallback
    from app.services.risk_engine import combined_risk_index
    return combined_risk_index(
        heat_score, lightning_score, flood_score, wildfire_score, wind_score, wildlife_score
    )
