"""
Offline training script — run once to generate model.pkl.
Uses synthetic data when NOAA Storm Events CSV is not available.
"""
import numpy as np
import pandas as pd
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import GradientBoostingClassifier
from sklearn.calibration import CalibratedClassifierCV
from sklearn.model_selection import cross_val_score
import joblib
from pathlib import Path
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

MODEL_PATH = Path(__file__).parent / "model.pkl"


def generate_synthetic_training_data(n_samples: int = 5000) -> pd.DataFrame:
    """
    Generate synthetic but realistic training data for the hackathon.

    In production: join NOAA Storm Events 2015-2023 with OSHA Severe Injury
    Reports within 25 miles / 24 hours of each event.
    """
    np.random.seed(42)

    data = []
    for _ in range(n_samples):
        # Base weather
        temp_f = np.random.normal(82, 15)
        humidity = np.random.uniform(40, 100)
        wind_mph = np.random.exponential(12)
        precip_in = np.random.exponential(0.1)

        heat_index_f = temp_f + (humidity - 40) * 0.1 if temp_f > 75 else temp_f

        # Alert flags
        has_thunder_watch = np.random.random() < 0.10
        has_thunder_warning = np.random.random() < 0.05
        has_flood_watch = np.random.random() < 0.08
        has_flood_warning = np.random.random() < 0.03
        has_heat_warning = np.random.random() < 0.06
        has_wind_advisory = np.random.random() < 0.07

        month = np.random.randint(1, 13)
        hour = np.random.randint(6, 20)
        is_weekday = int(np.random.random() < 0.7)

        # Sub-scores
        heat_score = 0.0
        if heat_index_f > 115: heat_score = 9.0
        elif heat_index_f > 103: heat_score = 5.0
        elif heat_index_f > 91: heat_score = 2.0
        if has_heat_warning: heat_score = min(10, heat_score + 1)

        lightning_score = 0.0
        if has_thunder_warning: lightning_score = 7.0
        elif has_thunder_watch: lightning_score = 4.0

        flood_score = 0.0
        if has_flood_warning: flood_score = 7.0
        elif has_flood_watch: flood_score = 3.0

        wind_score = 0.0
        if wind_mph > 65: wind_score = 10.0
        elif wind_mph > 50: wind_score = 7.0
        elif wind_mph > 35: wind_score = 5.0
        elif wind_mph > 25: wind_score = 2.0

        wildlife_score = float(np.random.choice([0, 3, 6], p=[0.85, 0.10, 0.05]))
        wildfire_score = float(np.random.choice([0, 5, 8], p=[0.90, 0.07, 0.03]))

        # Injury probability model
        risk_base = (
            lightning_score * 0.35
            + heat_score * 0.25
            + flood_score * 0.20
            + wind_score * 0.10
            + wildfire_score * 0.05
            + wildlife_score * 0.05
        ) / 10.0

        injury_prob = min(0.85, risk_base * 0.8 + np.random.normal(0, 0.03))
        injury = int(np.random.random() < injury_prob)

        data.append([
            temp_f, heat_index_f, wind_mph, precip_in, humidity,
            float(has_thunder_watch), float(has_thunder_warning),
            float(has_flood_watch), float(has_flood_warning),
            float(has_heat_warning), float(has_wind_advisory),
            float(month), float(hour), float(is_weekday),
            heat_score, lightning_score, flood_score, wildfire_score,
            wind_score, wildlife_score, injury
        ])

    columns = [
        "temp_f", "heat_index_f", "wind_mph", "precip_in", "humidity_pct",
        "has_thunder_watch", "has_thunder_warning",
        "has_flood_watch", "has_flood_warning",
        "has_heat_warning", "has_wind_advisory",
        "month", "hour", "is_weekday",
        "heat_score", "lightning_score", "flood_score", "wildfire_score",
        "wind_score", "wildlife_score", "injury_occurred"
    ]

    return pd.DataFrame(data, columns=columns)


def train():
    logger.info("Generating training data...")
    df = generate_synthetic_training_data(n_samples=10000)

    feature_cols = [c for c in df.columns if c != "injury_occurred"]
    X = df[feature_cols].values
    y = df["injury_occurred"].values

    logger.info(f"Training on {len(X)} samples, {y.mean():.1%} positive rate")

    pipeline = Pipeline([
        ("scaler", StandardScaler()),
        ("clf", CalibratedClassifierCV(
            GradientBoostingClassifier(
                n_estimators=200,
                max_depth=4,
                learning_rate=0.1,
                subsample=0.8,
                random_state=42,
            ),
            cv=5,
            method="isotonic",
        )),
    ])

    logger.info("Training model...")
    pipeline.fit(X, y)

    # Quick cross-validation check
    scores = cross_val_score(
        Pipeline([
            ("scaler", StandardScaler()),
            ("clf", GradientBoostingClassifier(n_estimators=50, max_depth=4, random_state=42)),
        ]),
        X, y, cv=3, scoring="roc_auc"
    )
    logger.info(f"CV ROC-AUC: {scores.mean():.3f} ± {scores.std():.3f}")

    joblib.dump(pipeline, MODEL_PATH)
    logger.info(f"Model saved to {MODEL_PATH}")


if __name__ == "__main__":
    train()
