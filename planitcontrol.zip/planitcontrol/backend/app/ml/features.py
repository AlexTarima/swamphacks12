"""Shared feature extraction for ML model."""
from typing import Dict, Any, Optional
import numpy as np


FEATURE_NAMES = [
    "temp_f",
    "heat_index_f",
    "wind_mph",
    "precip_in",
    "humidity_pct",
    "has_thunder_watch",
    "has_thunder_warning",
    "has_flood_watch",
    "has_flood_warning",
    "has_heat_warning",
    "has_wind_advisory",
    "month",
    "hour",
    "is_weekday",
    "heat_score",
    "lightning_score",
    "flood_score",
    "wildfire_score",
    "wind_score",
    "wildlife_score",
]


def extract_features(
    temp_f: Optional[float] = None,
    heat_index_f: Optional[float] = None,
    wind_mph: Optional[float] = None,
    precip_in: Optional[float] = None,
    humidity_pct: Optional[float] = None,
    nws_alerts: Optional[list] = None,
    heat_score: float = 0.0,
    lightning_score: float = 0.0,
    flood_score: float = 0.0,
    wildfire_score: float = 0.0,
    wind_score: float = 0.0,
    wildlife_score: float = 0.0,
    timestamp=None,
) -> np.ndarray:
    """Extract feature vector for ML prediction."""
    from datetime import datetime, timezone

    alerts = nws_alerts or []
    alert_events = [a.get("event", "").lower() for a in alerts]

    has_thunder_watch = any("thunderstorm watch" in e for e in alert_events)
    has_thunder_warning = any("thunderstorm warning" in e or "severe thunderstorm" in e for e in alert_events)
    has_flood_watch = any("flood watch" in e for e in alert_events)
    has_flood_warning = any("flood warning" in e for e in alert_events)
    has_heat_warning = any("heat warning" in e or "excessive heat" in e for e in alert_events)
    has_wind_advisory = any("wind advisory" in e or "high wind" in e for e in alert_events)

    now = timestamp or datetime.now(timezone.utc)
    month = now.month
    hour = now.hour
    is_weekday = int(now.weekday() < 5)

    features = np.array([
        temp_f or 80.0,
        heat_index_f or temp_f or 80.0,
        wind_mph or 0.0,
        precip_in or 0.0,
        humidity_pct or 60.0,
        float(has_thunder_watch),
        float(has_thunder_warning),
        float(has_flood_watch),
        float(has_flood_warning),
        float(has_heat_warning),
        float(has_wind_advisory),
        float(month),
        float(hour),
        float(is_weekday),
        heat_score,
        lightning_score,
        flood_score,
        wildfire_score,
        wind_score,
        wildlife_score,
    ], dtype=float)

    return features.reshape(1, -1)
