from sqlalchemy import Column, Integer, BigInteger, Float, Text, TIMESTAMP, ForeignKey
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.sql import func
from app.database import Base


class HazardSnapshot(Base):
    __tablename__ = "hazard_snapshots"

    id = Column(BigInteger, primary_key=True, autoincrement=True)
    plant_id = Column(Integer, ForeignKey("plants.id"), index=True)
    recorded_at = Column(TIMESTAMP(timezone=True), server_default=func.now())

    # Weather
    temp_f = Column(Float)
    heat_index_f = Column(Float)
    wind_mph = Column(Float)
    precip_in = Column(Float)
    humidity_pct = Column(Float)
    nws_alerts = Column(JSONB, default=[])

    # Flood
    usgs_gauge_ft = Column(Float)
    flood_stage_ft = Column(Float)

    # Wildfire
    wildfire_risk_level = Column(Text)

    # Sub-scores (0-10)
    heat_score = Column(Float, default=0.0)
    lightning_score = Column(Float, default=0.0)
    flood_score = Column(Float, default=0.0)
    wildfire_score = Column(Float, default=0.0)
    wind_score = Column(Float, default=0.0)
    wildlife_score = Column(Float, default=0.0)
    ml_risk_index = Column(Float, default=0.0)
