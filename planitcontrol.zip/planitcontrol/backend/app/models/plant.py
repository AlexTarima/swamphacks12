from sqlalchemy import Column, Integer, String, Float, Text
from geoalchemy2 import Geography
from app.database import Base


class Plant(Base):
    __tablename__ = "plants"

    id = Column(Integer, primary_key=True, index=True)
    eia_plant_id = Column(Integer, unique=True, nullable=True)
    name = Column(Text, nullable=False)
    utility = Column(Text)
    state = Column(String(2))
    county = Column(Text)
    technology = Column(Text)
    capacity_mw = Column(Float)
    geom = Column(Geography(geometry_type="POINT", srid=4326), nullable=False)
    latitude = Column(Float)
    longitude = Column(Float)
    timezone = Column(Text, default="America/New_York")
    usgs_gauge_id = Column(Text, nullable=True)
    flood_stage_ft = Column(Float, nullable=True)
    nws_office = Column(Text, nullable=True)
    nws_grid_x = Column(Integer, nullable=True)
    nws_grid_y = Column(Integer, nullable=True)
