from sqlalchemy import Column, Integer, Float, TIMESTAMP, ForeignKey
from sqlalchemy.sql import func
from app.database import Base


class RiskScore(Base):
    __tablename__ = "risk_scores"

    id = Column(Integer, primary_key=True, autoincrement=True)
    plant_id = Column(Integer, ForeignKey("plants.id"), index=True)
    scored_at = Column(TIMESTAMP(timezone=True), server_default=func.now())
    overall_score = Column(Float, default=0.0)
    heat_score = Column(Float, default=0.0)
    lightning_score = Column(Float, default=0.0)
    flood_score = Column(Float, default=0.0)
    wildfire_score = Column(Float, default=0.0)
    wind_score = Column(Float, default=0.0)
    wildlife_score = Column(Float, default=0.0)
    ml_score = Column(Float, default=0.0)
