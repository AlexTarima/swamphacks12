from sqlalchemy import Column, Integer, Text, TIMESTAMP, Float, ForeignKey
from geoalchemy2 import Geography
from sqlalchemy.sql import func
from app.database import Base


class CrewReport(Base):
    __tablename__ = "crew_reports"

    id = Column(Integer, primary_key=True, autoincrement=True)
    plant_id = Column(Integer, ForeignKey("plants.id"), index=True)
    reporter_name = Column(Text)
    hazard_type = Column(Text)
    notes = Column(Text)
    photo_path = Column(Text)
    geom = Column(Geography(geometry_type="POINT", srid=4326))
    latitude = Column(Float)
    longitude = Column(Float)
    reported_at = Column(TIMESTAMP(timezone=True), server_default=func.now())
