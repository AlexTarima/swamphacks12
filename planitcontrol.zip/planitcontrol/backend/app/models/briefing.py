from sqlalchemy import Column, Integer, Text, TIMESTAMP, ForeignKey
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.sql import func
from app.database import Base


class Briefing(Base):
    __tablename__ = "briefings"

    id = Column(Integer, primary_key=True, autoincrement=True)
    plant_id = Column(Integer, ForeignKey("plants.id"), index=True)
    generated_at = Column(TIMESTAMP(timezone=True), server_default=func.now())
    briefing_date = Column(Text)    # YYYY-MM-DD
    summary = Column(Text)
    hazards = Column(JSONB, default=[])
    safety_actions = Column(JSONB, default=[])
    hourly_forecast = Column(JSONB, default=[])
    raw_forecast = Column(JSONB, default={})
