from sqlalchemy import Column, BigInteger, TIMESTAMP
from geoalchemy2 import Geography
from sqlalchemy.sql import func
from app.database import Base


class LightningStrike(Base):
    __tablename__ = "lightning_strikes"

    id = Column(BigInteger, primary_key=True, autoincrement=True)
    geom = Column(Geography(geometry_type="POINT", srid=4326), nullable=False)
    struck_at = Column(TIMESTAMP(timezone=True), server_default=func.now())
