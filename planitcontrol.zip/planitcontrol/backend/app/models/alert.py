from sqlalchemy import Column, Integer, Text, TIMESTAMP, ForeignKey
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.sql import func
from app.database import Base


class Alert(Base):
    __tablename__ = "alerts"

    id = Column(Integer, primary_key=True, autoincrement=True)
    plant_id = Column(Integer, ForeignKey("plants.id"), index=True)
    alert_type = Column(Text)        # 'lightning', 'flood', 'heat'
    status = Column(Text, default="active")  # 'active', 'cleared', 'acknowledged'
    triggered_at = Column(TIMESTAMP(timezone=True), server_default=func.now())
    last_strike_at = Column(TIMESTAMP(timezone=True))
    all_clear_at = Column(TIMESTAMP(timezone=True))
    strike_count = Column(Integer, default=0)
    metadata_ = Column("metadata", JSONB, default={})
