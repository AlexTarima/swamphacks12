"""
Seeds the database with realistic US power plant data.
Run with: python -m data.seed_plants (from /app directory inside docker)
Or: python seed_plants.py (from /app/data directory)
"""
import asyncio
import sys
import os

# Add backend to path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from sqlalchemy.ext.asyncio import create_async_engine, async_sessionmaker
from sqlalchemy import select, text

DATABASE_URL = os.getenv(
    "DATABASE_URL",
    "postgresql+asyncpg://planituser:planitpass@localhost:5432/planitcontrol"
)

# 50+ realistic power plant data with lat/lon
PLANTS = [
    # Florida
    {"eia_plant_id": 2186, "name": "Turkey Point Nuclear", "utility": "FPL", "state": "FL", "county": "Miami-Dade", "technology": "Nuclear", "capacity_mw": 1632, "lat": 25.4344, "lon": -80.3311, "tz": "America/New_York"},
    {"eia_plant_id": 2187, "name": "St. Lucie Nuclear", "utility": "FPL", "state": "FL", "county": "St. Lucie", "technology": "Nuclear", "capacity_mw": 1768, "lat": 27.3478, "lon": -80.2453, "tz": "America/New_York"},
    {"eia_plant_id": 637, "name": "Crystal River Energy Complex", "utility": "Duke Energy", "state": "FL", "county": "Citrus", "technology": "Natural Gas", "capacity_mw": 2100, "lat": 28.9669, "lon": -82.6887, "tz": "America/New_York"},
    {"eia_plant_id": 2188, "name": "Manatee Energy Center", "utility": "FPL", "state": "FL", "county": "Manatee", "technology": "Natural Gas", "capacity_mw": 1830, "lat": 27.6535, "lon": -81.8095, "tz": "America/New_York"},
    {"eia_plant_id": 2189, "name": "Canaveral Generating Station", "utility": "FPL", "state": "FL", "county": "Brevard", "technology": "Natural Gas", "capacity_mw": 1218, "lat": 28.3922, "lon": -80.6037, "tz": "America/New_York"},
    {"eia_plant_id": 2190, "name": "Port Everglades Power Plant", "utility": "FPL", "state": "FL", "county": "Broward", "technology": "Natural Gas", "capacity_mw": 1256, "lat": 26.0980, "lon": -80.1309, "tz": "America/New_York"},
    {"eia_plant_id": 2191, "name": "Cutler Power Plant", "utility": "FPL", "state": "FL", "county": "Miami-Dade", "technology": "Natural Gas", "capacity_mw": 498, "lat": 25.6244, "lon": -80.3365, "tz": "America/New_York"},
    {"eia_plant_id": 2192, "name": "Riviera Energy Center", "utility": "FPL", "state": "FL", "county": "Palm Beach", "technology": "Natural Gas", "capacity_mw": 1470, "lat": 26.7779, "lon": -80.0717, "tz": "America/New_York"},
    {"eia_plant_id": 2193, "name": "Martin Clean Energy Center", "utility": "FPL", "state": "FL", "county": "Martin", "technology": "Solar", "capacity_mw": 75, "lat": 27.1119, "lon": -80.7665, "tz": "America/New_York"},
    {"eia_plant_id": 2194, "name": "DeSoto Next Generation Solar Energy Center", "utility": "FPL", "state": "FL", "county": "DeSoto", "technology": "Solar", "capacity_mw": 25, "lat": 27.1825, "lon": -81.8560, "tz": "America/New_York"},
    # Georgia
    {"eia_plant_id": 3001, "name": "Plant Vogtle", "utility": "Georgia Power", "state": "GA", "county": "Burke", "technology": "Nuclear", "capacity_mw": 4000, "lat": 33.1428, "lon": -81.7609, "tz": "America/New_York"},
    {"eia_plant_id": 3002, "name": "Plant Scherer", "utility": "Georgia Power", "state": "GA", "county": "Monroe", "technology": "Coal", "capacity_mw": 3520, "lat": 33.0594, "lon": -83.9000, "tz": "America/New_York"},
    {"eia_plant_id": 3003, "name": "Plant Bowen", "utility": "Georgia Power", "state": "GA", "county": "Bartow", "technology": "Coal", "capacity_mw": 3200, "lat": 34.2100, "lon": -84.8989, "tz": "America/New_York"},
    {"eia_plant_id": 3004, "name": "Plant McDonough-Atkinson", "utility": "Georgia Power", "state": "GA", "county": "Cobb", "technology": "Natural Gas", "capacity_mw": 1890, "lat": 33.7800, "lon": -84.5400, "tz": "America/New_York"},
    {"eia_plant_id": 3005, "name": "Plant Wansley", "utility": "Georgia Power", "state": "GA", "county": "Heard", "technology": "Natural Gas", "capacity_mw": 1955, "lat": 33.5197, "lon": -85.1206, "tz": "America/New_York"},
    # Texas
    {"eia_plant_id": 4001, "name": "South Texas Project", "utility": "NRG", "state": "TX", "county": "Matagorda", "technology": "Nuclear", "capacity_mw": 2700, "lat": 28.7953, "lon": -96.0492, "tz": "America/Chicago"},
    {"eia_plant_id": 4002, "name": "Comanche Peak Nuclear", "utility": "Luminant", "state": "TX", "county": "Somervell", "technology": "Nuclear", "capacity_mw": 2430, "lat": 32.2978, "lon": -97.7814, "tz": "America/Chicago"},
    {"eia_plant_id": 4003, "name": "W.A. Parish Power Plant", "utility": "NRG", "state": "TX", "county": "Fort Bend", "technology": "Natural Gas", "capacity_mw": 2450, "lat": 29.4661, "lon": -95.6650, "tz": "America/Chicago"},
    {"eia_plant_id": 4004, "name": "Martin Lake Power Plant", "utility": "Luminant", "state": "TX", "county": "Rusk", "technology": "Coal", "capacity_mw": 2250, "lat": 32.2722, "lon": -94.5706, "tz": "America/Chicago"},
    {"eia_plant_id": 4005, "name": "Twin Oaks Power Plant", "utility": "NAES", "state": "TX", "county": "Robertson", "technology": "Coal", "capacity_mw": 1200, "lat": 30.8536, "lon": -96.4336, "tz": "America/Chicago"},
    {"eia_plant_id": 4006, "name": "Permian Basin Wind Farm", "utility": "NextEra", "state": "TX", "county": "Upton", "technology": "Wind", "capacity_mw": 1000, "lat": 31.6667, "lon": -102.3333, "tz": "America/Chicago"},
    {"eia_plant_id": 4007, "name": "Roscoe Wind Farm", "utility": "E.ON", "state": "TX", "county": "Nolan", "technology": "Wind", "capacity_mw": 781, "lat": 32.4522, "lon": -100.5375, "tz": "America/Chicago"},
    # North Carolina
    {"eia_plant_id": 5001, "name": "McGuire Nuclear Station", "utility": "Duke Energy", "state": "NC", "county": "Mecklenburg", "technology": "Nuclear", "capacity_mw": 2290, "lat": 35.4267, "lon": -80.9528, "tz": "America/New_York"},
    {"eia_plant_id": 5002, "name": "Brunswick Nuclear Plant", "utility": "Duke Energy", "state": "NC", "county": "Brunswick", "technology": "Nuclear", "capacity_mw": 1870, "lat": 34.0056, "lon": -78.0192, "tz": "America/New_York"},
    {"eia_plant_id": 5003, "name": "Shearon Harris Nuclear Plant", "utility": "Duke Energy", "state": "NC", "county": "Wake", "technology": "Nuclear", "capacity_mw": 940, "lat": 35.6331, "lon": -79.0983, "tz": "America/New_York"},
    {"eia_plant_id": 5004, "name": "Marshall Steam Station", "utility": "Duke Energy", "state": "NC", "county": "Catawba", "technology": "Coal", "capacity_mw": 2092, "lat": 35.5489, "lon": -80.9958, "tz": "America/New_York"},
    {"eia_plant_id": 5005, "name": "Belews Creek Steam Station", "utility": "Duke Energy", "state": "NC", "county": "Stokes", "technology": "Coal", "capacity_mw": 2240, "lat": 36.2414, "lon": -80.1258, "tz": "America/New_York"},
    # South Carolina
    {"eia_plant_id": 6001, "name": "V.C. Summer Nuclear Station", "utility": "Dominion", "state": "SC", "county": "Fairfield", "technology": "Nuclear", "capacity_mw": 966, "lat": 34.2944, "lon": -81.3231, "tz": "America/New_York"},
    {"eia_plant_id": 6002, "name": "Catawba Nuclear Station", "utility": "Duke Energy", "state": "SC", "county": "York", "technology": "Nuclear", "capacity_mw": 2258, "lat": 35.0622, "lon": -81.0736, "tz": "America/New_York"},
    {"eia_plant_id": 6003, "name": "H.B. Robinson Steam Electric Plant", "utility": "Duke Energy", "state": "SC", "county": "Darlington", "technology": "Nuclear", "capacity_mw": 900, "lat": 34.4008, "lon": -80.1567, "tz": "America/New_York"},
    # Alabama
    {"eia_plant_id": 7001, "name": "Farley Nuclear Plant", "utility": "Alabama Power", "state": "AL", "county": "Houston", "technology": "Nuclear", "capacity_mw": 1776, "lat": 31.2239, "lon": -85.1119, "tz": "America/Chicago"},
    {"eia_plant_id": 7002, "name": "Browns Ferry Nuclear Plant", "utility": "TVA", "state": "AL", "county": "Lawrence", "technology": "Nuclear", "capacity_mw": 3376, "lat": 34.7039, "lon": -87.1197, "tz": "America/Chicago"},
    {"eia_plant_id": 7003, "name": "Gaston Steam Plant", "utility": "Alabama Power", "state": "AL", "county": "Shelby", "technology": "Natural Gas", "capacity_mw": 1570, "lat": 33.3567, "lon": -86.4819, "tz": "America/Chicago"},
    # Mississippi
    {"eia_plant_id": 8001, "name": "Grand Gulf Nuclear Station", "utility": "Entergy", "state": "MS", "county": "Claiborne", "technology": "Nuclear", "capacity_mw": 1300, "lat": 32.0075, "lon": -91.0481, "tz": "America/Chicago"},
    {"eia_plant_id": 8002, "name": "Daniel Power Plant", "utility": "Gulf Power", "state": "MS", "county": "Jackson", "technology": "Coal", "capacity_mw": 1046, "lat": 30.4400, "lon": -88.5000, "tz": "America/Chicago"},
    # Louisiana
    {"eia_plant_id": 9001, "name": "River Bend Nuclear Station", "utility": "Entergy", "state": "LA", "county": "West Feliciana", "technology": "Nuclear", "capacity_mw": 974, "lat": 30.7556, "lon": -91.3317, "tz": "America/Chicago"},
    {"eia_plant_id": 9002, "name": "Waterford Nuclear Plant", "utility": "Entergy", "state": "LA", "county": "St. Charles", "technology": "Nuclear", "capacity_mw": 1250, "lat": 29.9933, "lon": -90.4811, "tz": "America/Chicago"},
    {"eia_plant_id": 9003, "name": "Ninemile Point Power Plant", "utility": "Entergy", "state": "LA", "county": "Jefferson", "technology": "Natural Gas", "capacity_mw": 550, "lat": 29.9500, "lon": -90.1900, "tz": "America/Chicago"},
    # Virginia
    {"eia_plant_id": 10001, "name": "North Anna Power Station", "utility": "Dominion", "state": "VA", "county": "Louisa", "technology": "Nuclear", "capacity_mw": 1892, "lat": 38.0617, "lon": -77.7972, "tz": "America/New_York"},
    {"eia_plant_id": 10002, "name": "Surry Power Station", "utility": "Dominion", "state": "VA", "county": "Surry", "technology": "Nuclear", "capacity_mw": 1676, "lat": 37.1650, "lon": -76.6981, "tz": "America/New_York"},
    {"eia_plant_id": 10003, "name": "Chesterfield Power Station", "utility": "Dominion", "state": "VA", "county": "Chesterfield", "technology": "Natural Gas", "capacity_mw": 1470, "lat": 37.3617, "lon": -77.3550, "tz": "America/New_York"},
    # Tennessee
    {"eia_plant_id": 11001, "name": "Watts Bar Nuclear Plant", "utility": "TVA", "state": "TN", "county": "Rhea", "technology": "Nuclear", "capacity_mw": 2340, "lat": 35.6047, "lon": -84.7858, "tz": "America/New_York"},
    {"eia_plant_id": 11002, "name": "Sequoyah Nuclear Plant", "utility": "TVA", "state": "TN", "county": "Hamilton", "technology": "Nuclear", "capacity_mw": 2452, "lat": 35.2261, "lon": -85.0936, "tz": "America/New_York"},
    {"eia_plant_id": 11003, "name": "Cumberland Fossil Plant", "utility": "TVA", "state": "TN", "county": "Stewart", "technology": "Coal", "capacity_mw": 2600, "lat": 36.3853, "lon": -87.6350, "tz": "America/Chicago"},
    # Arkansas
    {"eia_plant_id": 12001, "name": "Arkansas Nuclear One", "utility": "Entergy", "state": "AR", "county": "Pope", "technology": "Nuclear", "capacity_mw": 1854, "lat": 35.3108, "lon": -93.2303, "tz": "America/Chicago"},
    # Oklahoma
    {"eia_plant_id": 13001, "name": "Redbud Power Plant", "utility": "OGE", "state": "OK", "county": "Canadian", "technology": "Natural Gas", "capacity_mw": 2510, "lat": 35.6272, "lon": -97.9197, "tz": "America/Chicago"},
    {"eia_plant_id": 13002, "name": "Sooner Power Plant", "utility": "OGE", "state": "OK", "county": "Noble", "technology": "Coal", "capacity_mw": 1078, "lat": 36.3897, "lon": -97.1822, "tz": "America/Chicago"},
    # Kentucky
    {"eia_plant_id": 14001, "name": "Paradise Fossil Plant", "utility": "TVA", "state": "KY", "county": "Muhlenberg", "technology": "Natural Gas", "capacity_mw": 1100, "lat": 37.1661, "lon": -87.0897, "tz": "America/Chicago"},
    {"eia_plant_id": 14002, "name": "Ghent Power Plant", "utility": "LG&E", "state": "KY", "county": "Carroll", "technology": "Coal", "capacity_mw": 2216, "lat": 38.7217, "lon": -85.0719, "tz": "America/New_York"},
    # New Mexico
    {"eia_plant_id": 15001, "name": "Four Corners Power Plant", "utility": "Arizona Public Service", "state": "NM", "county": "San Juan", "technology": "Coal", "capacity_mw": 1480, "lat": 36.7036, "lon": -108.4781, "tz": "America/Denver"},
    {"eia_plant_id": 15002, "name": "San Juan Generating Station", "utility": "PNM", "state": "NM", "county": "San Juan", "technology": "Coal", "capacity_mw": 847, "lat": 36.7797, "lon": -108.4769, "tz": "America/Denver"},
]


async def seed():
    from app.database import Base
    from app.models.plant import Plant
    from app.models.hazard_snapshot import HazardSnapshot
    from app.models.alert import Alert
    from app.models.crew_report import CrewReport
    from app.models.briefing import Briefing
    from app.models.risk_score import RiskScore
    from app.models.lightning_strike import LightningStrike

    engine = create_async_engine(DATABASE_URL, echo=False)
    SessionLocal = async_sessionmaker(engine, expire_on_commit=False)

    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)

    async with SessionLocal() as db:
        # Check if already seeded
        result = await db.execute(select(Plant).limit(1))
        if result.scalar_one_or_none():
            print(f"Database already has plants. Skipping seed.")
            return

        print(f"Seeding {len(PLANTS)} plants...")
        for p in PLANTS:
            plant = Plant(
                eia_plant_id=p["eia_plant_id"],
                name=p["name"],
                utility=p["utility"],
                state=p["state"],
                county=p["county"],
                technology=p["technology"],
                capacity_mw=p["capacity_mw"],
                latitude=p["lat"],
                longitude=p["lon"],
                geom=f"SRID=4326;POINT({p['lon']} {p['lat']})",
                timezone=p["tz"],
            )
            db.add(plant)

        await db.commit()
        print(f"Seeded {len(PLANTS)} plants")

    await engine.dispose()


if __name__ == "__main__":
    asyncio.run(seed())
