#!/bin/bash
# Run from inside the backend docker container
cd /app
python data/seed_plants.py
