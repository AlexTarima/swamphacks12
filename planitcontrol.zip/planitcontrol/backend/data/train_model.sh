#!/bin/bash
# Run from inside the backend docker container
cd /app
python -m app.ml.train
