# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Running the project

```bash
# Full stack (requires Docker Desktop)
docker-compose up

# First boot auto-runs: DB seed → ML training → uvicorn
# Frontend: http://localhost:5173
# API:      http://localhost:8000
# API docs: http://localhost:8000/docs
```

**Without Docker — backend:**
```bash
cd backend
pip install -r requirements.txt
# DATABASE_URL must be set in .env pointing to a running PostGIS instance
python data/seed_plants.py        # one-time, idempotent
python -m app.ml.train            # generates app/ml/model.pkl
uvicorn app.main:socket_app --host 0.0.0.0 --port 8000 --reload
```

**Without Docker — frontend:**
```bash
cd frontend
npm install
npm run dev      # http://localhost:5173
npm run build    # production build
```

**Retrain the ML model inside Docker:**
```bash
docker-compose exec backend python -m app.ml.train
```

**Re-seed the database (inside Docker):**
```bash
docker-compose exec backend python data/seed_plants.py
```

**Manually trigger a briefing generation:**
```bash
docker-compose exec backend python -c "
import asyncio
from app.services.briefing_generator import generate_daily_briefings
asyncio.run(generate_daily_briefings())
"
```

## Architecture

### The ASGI entrypoint

`backend/app/main.py` creates two objects: a FastAPI `app` and a `socketio.AsyncServer` (`sio`). They are combined into a single ASGI app via `socketio.ASGIApp(sio, other_asgi_app=app)` exported as `socket_app`. Uvicorn serves `socket_app`. The `sio` instance is stored on `app.state.sio` so routers can emit events by accessing `request.app.state.sio`.

### Request lifecycle for hazard data

1. **APScheduler** (started in `app/scheduler.py` on FastAPI startup) fires background jobs
2. `weather_poller.py` calls NOAA `api.weather.gov` for every plant, writes a `HazardSnapshot` row, and emits a `risk_update` Socket.io event to the `dashboard` room
3. `lightning_watcher.py` runs a persistent WebSocket loop to Blitzortung; on each strike it calls `ST_DWithin` (PostGIS, 10-mile radius) to find nearby plants, then calls `alert_dispatcher.create_or_reset_lightning_alert()` which upserts an `Alert` row and emits `lightning_alert` to `global_alerts` + `site_{plant_id}` rooms
4. Frontend `useSocket.ts` listens for these events and patches Zustand stores in-place — no polling needed for live updates

### Risk scoring pipeline

All scoring is in `backend/app/services/risk_engine.py`. The canonical entry point is `compute_all_scores()`, which calls six independent sub-score functions and then `combined_risk_index()`. The result dict maps directly to `HazardSnapshot` column names.

The ML layer in `app/ml/predictor.py` wraps a `joblib`-serialized `sklearn` pipeline. Its `score()` function accepts the same kwargs as `compute_all_scores()` and returns a 0–10 float. If `model.pkl` is missing at import time, it silently falls back to `combined_risk_index()`. **The rest of the codebase should always call `predictor.score()`, not `combined_risk_index()` directly**, so the ML/rule-based swap is transparent.

### Socket.io rooms

| Room | Who joins | What it receives |
|------|-----------|-----------------|
| `dashboard` | any client that calls `join_dashboard` | `risk_update`, `crew_report_new` |
| `global_alerts` | same (joined together with dashboard) | `lightning_alert` |
| `site_{plant_id}` | clients that call `join_site` with a plant_id | `lightning_alert`, `flood_warning` |

### Frontend state model

Three Zustand stores, no React Context:
- `useSiteStore` — array of `Site` objects; `updateSiteRisk()` patches a single site in-place when a `risk_update` event arrives
- `useAlertStore` — array of active `AlertItem`s; `addOrUpdateAlert()` upserts by `(plant_id, alert_type)`
- `useMapStore` — map center/zoom/selected site ID

`useSocket.ts` is a module-level singleton (the `socket` variable is outside the hook) so the connection survives component remounts. It is called once at the `App` level.

### Plant geometry

`Plant.geom` is a PostGIS `Geography(POINT, 4326)`. The WKT insertion format is `"SRID=4326;POINT({lon} {lat})"` — **longitude first**. Plain `latitude`/`longitude` float columns are stored in parallel for convenience (no PostGIS query needed for map rendering). The `ST_DWithin` spatial query in `lightning_watcher.py` uses the `geom` column with a radius in meters.

## Key conventions

- **All DB access is async** via `AsyncSession` / `asyncpg`. Never use a sync session outside of `seed_plants.py`.
- **Services open their own sessions** using `AsyncSessionLocal()` as a context manager. They do not receive a session as a parameter (because they run from APScheduler, not from a request context).
- **Routers receive sessions** via `Depends(get_db)`.
- **`sio` is passed as a function argument** to all services and scheduler jobs — never imported directly from `main.py` to avoid circular imports. The scheduler uses delayed imports inside `start_scheduler()` for the same reason.
- **`HazardSnapshot` is append-only** — each poll writes a new row. To get current conditions, always query with `.order_by(recorded_at.desc()).limit(1)`.
- No Alembic migrations are set up yet — `Base.metadata.create_all` runs on startup. When adding a new column, drop and recreate (dev) or write a raw `ALTER TABLE` (demo).
- Frontend env vars: `VITE_API_URL` for REST calls, `VITE_WS_URL` for Socket.io. Both default to `http://localhost:8000` in development.
