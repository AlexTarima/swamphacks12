"""Recover readable SQLite rows into a separate file; never modifies the source."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import shutil
import sqlite3


def quote(identifier):
    return '"' + identifier.replace('"', '""') + '"'


root = Path(__file__).resolve().parents[1]
source = root / 'sites.db'
stamp = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')
backup = root / '.cache' / ('sites.corrupt-original.' + stamp + '.db')
target = root / '.cache' / ('sites.recovered.' + stamp + '.db')
manifest_path = root / '.cache' / ('sites.recovery.' + stamp + '.json')
if target.exists() or backup.exists():
    raise SystemExit('Refusing to overwrite existing recovery artifacts')
before_hash = hashlib.sha256(source.read_bytes()).hexdigest()
shutil.copy2(source, backup)
src = sqlite3.connect(backup.as_uri() + '?mode=ro&immutable=1', uri=True)
dst = sqlite3.connect(target)
schema = src.execute("SELECT type,name,tbl_name,sql FROM sqlite_master WHERE sql IS NOT NULL").fetchall()
manifest = {'source': str(source), 'untouched_source_sha256': before_hash, 'backup': str(backup),
            'recovered': str(target), 'checked_at': datetime.now(timezone.utc).isoformat(),
            'original_quick_check': src.execute('PRAGMA quick_check').fetchall(), 'tables': {}}

for kind, name, table_name, sql in schema:
    if kind == 'table' and not name.startswith('sqlite_'):
        dst.execute(sql)

for kind, name, table_name, sql in schema:
    if kind != 'table':
        continue
    report = {'copied_rows': 0, 'failed_rows': [], 'enumeration_error': None}
    manifest['tables'][name] = report
    if name == 'sqlite_sequence':
        dst.execute('DELETE FROM sqlite_sequence')
    columns = src.execute('PRAGMA table_info(' + quote(name) + ')').fetchall()
    column_names = [column[1] for column in columns]
    select_columns = ','.join(quote(column) for column in column_names)
    insert = 'INSERT INTO ' + quote(name) + ' (' + select_columns + ') VALUES (' + ','.join('?' for _ in columns) + ')'
    try:
        rowids = [row[0] for row in src.execute('SELECT rowid FROM ' + quote(name) + ' NOT INDEXED')]
    except sqlite3.DatabaseError as error:
        report['enumeration_error'] = str(error)
        continue
    report['enumerated_rows'] = len(rowids)
    for rowid in rowids:
        try:
            row = src.execute('SELECT ' + select_columns + ' FROM ' + quote(name) + ' WHERE rowid=?', (rowid,)).fetchone()
            dst.execute(insert, row)
            report['copied_rows'] += 1
        except sqlite3.DatabaseError as error:
            failure = {'rowid': rowid, 'error': str(error)}
            if name == 'risk_snapshots':
                try:
                    failure['readable_metadata'] = src.execute('SELECT site_id,generated_at FROM risk_snapshots WHERE rowid=?', (rowid,)).fetchone()
                except sqlite3.DatabaseError:
                    pass
            report['failed_rows'].append(failure)

for kind, name, table_name, sql in schema:
    if kind in ('index', 'trigger', 'view'):
        dst.execute(sql)
dst.commit()
manifest['recovered_quick_check'] = dst.execute('PRAGMA quick_check').fetchall()
manifest['recovered_integrity_check'] = dst.execute('PRAGMA integrity_check').fetchall()
dst.close()
src.close()
after_hash = hashlib.sha256(source.read_bytes()).hexdigest()
manifest['source_unchanged'] = before_hash == after_hash
manifest_path.write_text(json.dumps(manifest, indent=2), encoding='utf-8')
print(json.dumps({'manifest': str(manifest_path), **manifest}, indent=2))
if not manifest['source_unchanged'] or manifest['recovered_integrity_check'] != [('ok',)]:
    raise SystemExit('Recovery verification failed; original was not replaced')
